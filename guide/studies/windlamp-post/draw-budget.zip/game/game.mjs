const W = 960, H = 540, END = 2770;
const ink = 0x111b24, paper = 0xf8e7c6, brass = 0xeeb877, mist = 0xa9c4c6;
const road = [[-100,455,422],[590,1025,411],[1061,1117,449],[1150,1558,399],[1606,1694,429],[1748,2121,416],[2271,2830,416]];
const spans = [[454,591,422],[2120,2272,416]];
const posts = [[351,422,'松口'],[1314,399,'石脊'],[1944,416,'望驿坡']];
const winds = [[867,1193,0,0.2],[1420,1780,1,1.15],[2050,2320,2,2.5]];
const clamp = (v,a,b) => Math.max(a,Math.min(b,v));
const wrap = (v,m) => ((v % m) + m) % m;
let s;

function box(g,x,y,w,h,c,a=1) {
  g.beginFill(c,a).drawRect(x,y,w,h).endFill();
}
function round(g,x,y,w,h,r,c,a=1) {
  g.beginFill(c,a).drawRoundRect(x,y,w,h,r).endFill();
}
function dot(g,x,y,r,c,a=1) {
  g.beginFill(c,a).drawCircle(x,y,r).endFill();
}
function poly(g,p,c,a=1) {
  g.beginFill(c,a).moveTo(p[0],p[1]);
  for (let i=2;i<p.length;i+=2) g.lineTo(p[i],p[i+1]);
  g.lineTo(p[0],p[1]).endFill();
}
function line(g,p,c,w=1,a=1) {
  g.lineStyle(w,c,a).moveTo(p[0],p[1]);
  for (let i=2;i<p.length;i+=2) g.lineTo(p[i],p[i+1]);
  g.lineStyle();
}
function oval(g,x,y,w,h,c,a=1) {
  g.beginFill(c,a).drawEllipse(x,y,w,h).endFill();
}
function place(game,x,y,draw,layer) {
  const piece = game.sprite(draw,layer);
  piece.x=x;
  piece.y=y;
  return piece;
}
function words(game,text,x,y,size,color=paper,align='left',bold=false) {
  return game.text(text,{x,y,size,color,align,bold,layer:game.ui});
}
function envelope(g,x,y,k,c=paper) {
  box(g,x,y,24*k,16*k,c);
  line(g,[x,y,x+12*k,y+9*k,x+24*k,y],0x9b684e,k);
  line(g,[x,y+16*k,x+8*k,y+8*k],0x9b684e,k,0.65);
  line(g,[x+24*k,y+16*k,x+16*k,y+8*k],0x9b684e,k,0.65);
  dot(g,x+12*k,y+9*k,2.3*k,0xae4f42);
}
function diamond(g,x,y,r,c,a=1) {
  poly(g,[x,y-r,x+r,y,x,y+r,x-r,y],c,a);
}
function fir(g,x,y,h,c,edge) {
  const b=h*0.24;
  poly(g,[x-2,y,x-1,y-h+8,x+2,y-h+10,x+3,y],c);
  poly(g,[x,y-h,x+b*.53,y-h*.62,x+b*.25,y-h*.67,x+b*.78,y-h*.38,x+b*.44,y-h*.43,x+b,y-h*.12,x+3,y-h*.19,x-b*1.07,y-h*.1,x-b*.55,y-h*.39,x-b*.82,y-h*.32,x-b*.37,y-h*.64,x-b*.55,y-h*.6],c);
  if (edge) line(g,[x-1,y-h+3,x-b*.42,y-h*.64,x-b*.22,y-h*.67],edge,1.5,.65);
}
function mountain(g,x,y,w,h,c,face,snow) {
  const crest=[x-w*.58,y,x-w*.39,y-h*.27,x-w*.22,y-h*.38,x-w*.09,y-h*.75,x,y-h,x+w*.16,y-h*.63,x+w*.25,y-h*.54,x+w*.42,y-h*.22,x+w*.66,y];
  poly(g,crest,c);
  poly(g,[x,y-h,x+w*.16,y-h*.63,x+w*.25,y-h*.54,x+w*.42,y-h*.22,x+w*.66,y,x+w*.15,y,x+w*.19,y-h*.24,x+w*.05,y-h*.48,x+w*.063,y-h*.6],face);
  poly(g,[x,y-h,x-w*.09,y-h*.75,x-w*.22,y-h*.38,x-w*.105,y-h*.51,x-w*.065,y-h*.64,x-w*.02,y-h*.57,x+w*.005,y-h*.76,x+w*.063,y-h*.6,x+w*.12,y-h*.62],snow,.64);
  line(g,[x-w*.36,y-h*.13,x-w*.2,y-h*.23,x-w*.14,y-h*.37,x-w*.08,y-h*.43],snow,1,.28);
}
function landscape(game) {
  place(game,0,0,g=>{
    g.beginLinearGradientFill(0,0,0,535,[{offset:0,color:0x172b42},{offset:.46,color:0x486a7a},{offset:.75,color:0x91a9aa},{offset:1,color:0x44616b}]).drawRect(0,0,W,H).endFill();
    dot(g,704,151,53,0xf4dfb4,.07);
    dot(g,704,151,43,0xffedcc,.14);
    dot(g,704,151,32,0xf3dfb8,.88);
    line(g,[678,163,712,163,727,160],0xa99e99,1.5,.52);
    line(g,[683,174,722,174],0xb1a49a,1,.5);
  });
  const clouds=place(game,0,0,g=>{
    for (let i=0;i<12;i++) {
      const x=-230+i*138, y=106+(i*31)%112, w=132+(i*19)%145;
      poly(g,[x-62,y+8,x+w*.37,y-9,x+w,y-8,x+w*.73,y+1,x+w+29,y+4,x+w*.28,y+14],i%3===0?0xb8c2bb:0x253d54,i%3===0?.16:.24);
      line(g,[x,y+13,x+w*.67,y+8],0xe1d7c0,1,.15);
    }
    poly(g,[534,155,687,145,794,149,892,144,777,158,618,164],0x486275,.63);
    line(g,[559,167,651,162,793,157],0xf0d6b0,1,.23);
  });
  const far=place(game,0,0,g=>{
    [[46,397,302,171],[270,388,428,230],[510,385,287,147],[721,385,431,201],[959,390,306,156],[1160,393,378,227],[1410,385,440,184]].forEach(([x,y,w,h])=>mountain(g,x,y,w,h,0x526f80,0x496676,0xafb7b0));
    poly(g,[-150,348,112,360,373,327,616,348,884,316,1135,335,1590,303,1590,540,-150,540],0xb9c8c0,.2);
  });
  const mid=place(game,0,0,g=>{
    [[-30,430,360,148],[187,441,289,95],[460,431,450,123],[720,438,300,92],[973,433,446,156],[1284,442,400,126],[1521,436,343,161]].forEach(([x,y,w,h])=>mountain(g,x,y,w,h,0x385766,0x2b4858,0x75949a));
    poly(g,[-130,395,88,389,203,404,351,384,557,403,676,389,901,397,1090,376,1306,391,1680,370,1690,540,-130,540],0x64818a);
    for(let i=0;i<78;i++) {
      const x=-109+i*24, y=416+Math.sin(i*.29)*9+(i*13)%12;
      fir(g,x,y,17+(i*47)%49,i%3===0?0x466977:0x527480);
    }
    poly(g,[-120,424,166,409,356,424,562,412,784,418,979,409,1205,415,1565,397,1800,411,1800,540,-120,540],0x78959a);
    poly(g,[-120,444,224,431,548,442,834,414,1066,428,1411,423,1800,432,1800,470,-120,478],0xafbfba,.31);
    for(let i=0;i<33;i++) {
      const x=-120+i*57, y=441+(i*23)%45;
      line(g,[x,y,x+20+i%5*12,y],i%3===0?0xd7d8bf:0xb1c5bf,1,.32);
    }
  });
  return [[clouds,.10],[far,.20],[mid,.38]];
}
function cliff(g,a,b,y,n) {
  const edge=[a,y];
  for(let x=a+22;x<b-14;x+=26) edge.push(x,y+5+(x*13%8+8)%8);
  edge.push(b,y);
  poly(g,[a,y,b,y,b-5,y+19,b-18,y+38,b-12,y+54,b-35,y+79,b-31,555,a+14,555,a+27,y+90,a+29,y+65,a+12,y+46,a+16,y+26],0x172a33);
  poly(g,[...edge,b-16,y+23,b-43,y+29,b-57,y+47,b-111,y+53,a+28,y+62,a+12,y+42,a+17,y+28],0x2b4146);
  for(let x=a+22,i=0;x<b-24;x+=31,i++) {
    const z=12+(i*11+n*7)%55;
    poly(g,[x,y+z,x+14,y+z-6,x+35,y+z-8,x+23,y+z+1,x+4,y+z+4],i%3===0?0x44565a:0x34484d,.67);
    if(i%2===0) line(g,[x+9,y+z+27,x+25,y+z+18,x+42,y+z+18],0x101f29,1.5,.7);
  }
  box(g,a,y,b-a,4,0x88938a);
  box(g,a+1,y+4,b-a-2,4,0x4f6260);
  for(let x=a+16,i=0;x<b-9;x+=15,i++) {
    const j=(i*17+n*7)%9;
    line(g,[x,y+1,x+4+j,y+1],i%3===0?0xc5b6a0:0x4f6967,1,.85);
    if(i%4===1) {
      line(g,[x-4,y+1,x-6,y-5-j,x-3,y-3,x-1,y-10,x+1,y],0x617c73,1.5);
      if(i%8===1) dot(g,x-1,y-9,1.7,0xb07858);
    }
  }
  line(g,[b-1,y+3,b-6,y+17,b-18,y+34],0x9da398,1.5,.62);
}
function cabin(game,x,y,inn) {
  const w=inn?238:120, h=inn?127:79;
  place(game,x,y,g=>{
    poly(g,[-23,0,0,-h,w,-h,w+9,-7,w+24,0],0x17232c);
    box(g,3,-h+6,w-6,h-12,inn?0x54483f:0x34424a);
    for(let yy=-h+13;yy<-8;yy+=10) line(g,[5,yy,w-5,yy],0x1c2b32,1,.65);
    box(g,0,-h,8,h,0x23313a);
    box(g,w-11,-h,11,h,0x28353a);
    const roof=inn?[-24,-h+9,26,-h-42,144,-h-65,220,-h-43,w+22,-h+8]:[-15,-h+7,14,-h-24,61,-h-45,105,-h-26,w+14,-h+7];
    box(g,w-46,-h-68,17,47,0x39414a);
    box(g,w-49,-h-70,23,7,0x70807f);
    poly(g,roof,0x223440);
    line(g,roof,0x9babaa,2);
    for(let j=0;j<4;j++) line(g,[-6+j*7,-h+3-j*9,54+j*10,-h-2-j*10,w-22+j*3,-h+4-j*9],0x455a63,1.5);
    box(g,-9,-h+5,w+19,7,0x17252e);
    const wx=inn?[26,158,195]:[21];
    for(const ox of wx) {
      const yr=inn?-80:-51;
      round(g,ox-4,yr-4,35,31,3,0x202831);
      box(g,ox,yr,27,23,inn?0xf3bb76:0x748585,.9);
      box(g,ox,yr+13,27,10,inn?0xcc7f4c:0x576c78);
      line(g,[ox+13,yr,ox+13,yr+23],0x553e38,2);
      line(g,[ox,yr+11,ox+27,yr+11],0x553e38,2);
      box(g,ox-4,yr+24,35,3,0x9b7962);
    }
    const door=inn?91:68;
    round(g,door-4,inn?-69:-52,inn?48:37,inn?69:52,4,0x22242a);
    box(g,door,inn?-62:-46,inn?40:29,inn?58:42,0x725343);
    for(let i=5;i<(inn?40:29);i+=8) line(g,[door+i,inn?-61:-45,door+i,-5],0x482f2d,1,.74);
    dot(g,door+24,-19,2,brass);
    box(g,door-9,-6,inn?58:48,6,0x384448);
    if(inn) {
      poly(g,[53,-2,94,-15,131,-15,170,-2],0xf5bc71,.22);
      round(g,73,-110,76,29,3,0x2f2526);
      line(g,[80,-107,143,-107],0xb58359,1);
      dot(g,60,-57,5,0xffc482);
      dot(g,60,-57,9,0xf7ae6b,.22);
    }
  });
  if(inn) game.text('风灯驿',{x:x+112,y:y-105,size:17,color:paper,align:'center',bold:true,layer:'world'});
}
function scenery(game) {
  const trees=[[-5,425,135],[136,422,67],[274,422,104],[441,423,53],[638,411,84],[724,411,118],[923,411,75],[1202,399,92],[1423,399,110],[1523,399,68],[1787,416,89],[1840,416,115],[2043,416,88],[2331,416,113],[2395,416,78],[2706,416,148],[2743,416,96]];
  place(game,0,0,g=>{
    for(const [x,y,h] of trees) fir(g,x,y,h,0x243e48,0x6c8c90);
    for(const [a,b,y] of road) for(let x=a+28;x<b-22;x+=95) {
      if(x<168 || x>2420) continue;
      const k=9+wrap(x*13,10);
      poly(g,[x-3,y,x+1,y-k*.27,x+k*.56,y-k*.62,x+k,y-k*.44,x+k*1.5,y],0x41585e);
      line(g,[x+1,y-k*.27,x+k*.56,y-k*.62,x+k,y-k*.44],0x78918f,1);
    }
  });
  cabin(game,28,422,false);
  cabin(game,2468,416,true);
  place(game,0,0,g=>road.forEach(([a,b,y],i)=>cliff(g,a,b,y,i)));
  place(game,0,0,g=>{
    for(const [a,b,y] of spans) {
      for(const x of [a-4,b+4]) {
        box(g,x-3,y-27,6,29,0x453d3b);
        box(g,x-4,y-27,8,3,0x9b8a75);
        line(g,[x-3,y-20,x+3,y-20],0xc09a6e,2);
      }
      line(g,[a-4,y-18,a+27,y+5,a+42,y+33],0x9b8a75,1.5,.8);
      line(g,[b+4,y-18,b-24,y+5,b-39,y+31],0x9b8a75,1.5,.8);
    }
    for(const [x,y] of [[967,411],[1501,399]]) {
      box(g,x-2,y-39,4,40,0x524945);
      poly(g,[x-15,y-50,x+12,y-48,x+20,y-40,x+11,y-33,x-15,y-36],0x8f7056);
      line(g,[x-9,y-42,x+10,y-41,x+5,y-45],paper,1.5,.85);
    }
    box(g,2535,384,15,21,0x883e3e);
    box(g,2534,383,17,3,0xcb7761);
    box(g,2538,389,9,2,ink);
    envelope(g,2539,395,.28);
  });
  return spans.map(([a,b,y])=>{
    const bridge=place(game,a,y,g=>{
      const w=b-a;
      box(g,0,1,w,9,0x3e3432);
      line(g,[0,8,19,14,w-19,14,w,8],0x6e584b,2);
      for(let x=0;x<w;x+=10) {
        box(g,x,0,9,5,x%20===0?0xb48a64:0x8d6c55);
        if(x%30===0) {
          box(g,x,-21,3,27,0x725747);
          dot(g,x+1,-20,2.1,brass,.85);
        }
      }
      line(g,[0,-18,w*.5,-15,w,-18],0xc2a786,1.4);
    });
    bridge.visible=false;
    return bridge;
  });
}
function lantern(game,x,y) {
  const glow=place(game,x+11,y-52,g=>{
    poly(g,[-89,0,-56,-37,0,-49,59,-34,88,2,65,43,0,51,-64,38],0xffb564,.07);
    poly(g,[-50,0,-34,-29,0,-37,34,-27,49,0,35,28,0,37,-36,27],0xffb15b,.14);
    poly(g,[-28,0,-17,-17,0,-23,18,-16,27,0,17,18,0,23,-17,17],0xffb65d,.25);
    oval(g,-57,49,114,13,0xffbc67,.17);
  });
  glow.visible=false;
  place(game,x,y,g=>{
    poly(g,[-10,0,-4,-9,-3,-66,0,-74,4,-69,5,-8,11,0],0x2e3032);
    box(g,1,-67,2,60,0x9b7961);
    line(g,[1,-65,14,-69,16,-63],0xa28970,2);
    line(g,[15,-65,12,-55,4,-21],0x484544,2);
    box(g,-7,-16,15,5,0x635745);
    oval(g,-11,-3,23,5,0x897962);
  });
  const cage=place(game,x+15,y-53,g=>lightGlass(g,false));
  const marker=place(game,x+15,y-95,g=>{
    diamond(g,0,0,8,0x182831,.94);
    diamond(g,0,0,5,brass);
    diamond(g,0,0,2,0x6d5546);
  });
  return {x,y,glow,cage,marker,lit:false};
}
function lightGlass(g,lit) {
  g.clear();
  poly(g,[-9,-7,-7,9,7,9,9,-7],0x222b33);
  poly(g,[-6,-6,-4,6,4,6,6,-6],lit?0xffb95f:0x637981);
  if(lit) poly(g,[-3,5,-1,-2,2,-5,3,3,1,6],0xfff2ad);
  line(g,[0,-6,0,7],0x4e4540,1,.77);
  poly(g,[-11,-7,-5,-12,5,-12,11,-7],0x3d3d3e);
  box(g,-7,8,14,2,0x9d7c60);
}
function courier(game) {
  const base=place(game,0,0,()=>{});
  const legs=[0,1].map((i)=>place(game,i?4:-4,-17,g=>{
    poly(g,[-4,-2,4,-2,4,12,1,17,-4,16,-3,9],i?0x3d4650:0x2b3740);
    poly(g,[-4,13,3,13,8,16,8,19,-5,19],0x242834);
    box(g,-4,17,11,2,0x856658);
  },base));
  const body=place(game,0,0,g=>{
    poly(g,[-10,-29,-3,-33,6,-32,12,-26,14,-12,-13,-12,-12,-22],0x723d3b);
    poly(g,[-8,-28,2,-30,9,-25,11,-16,3,-13,-9,-15],0xbd654c);
    line(g,[2,-28,4,-18,3,-13],0xe29062,1.3);
    poly(g,[4,-26,9,-24,11,-15,7,-12,4,-16,2,-22],0x994d40);
    dot(g,9,-13,2.7,0xe7ac7e);
    poly(g,[-6,-43,4,-46,11,-41,11,-34,8,-31,1,-30,-5,-35],0xdd9c72);
    poly(g,[-11,-39,-11,-43,-5,-49,3,-50,8,-47,10,-43,16,-42,16,-39,5,-38,-3,-40],0x8b4840);
    line(g,[-9,-43,-4,-47,3,-48,8,-45],0xd38061,1.5);
    box(g,8,-39,2,2,ink);
    line(g,[-7,-32,0,-30,8,-31],0xeed3a6,4);
    line(g,[0,-28,-4,-19,-10,-15],0xf0bf7d,2);
    round(g,-15,-23,12,12,3,0x60433d);
    box(g,-14,-22,9,6,0xc48a56);
    box(g,-10,-19,2,3,paper);
  },base);
  const scarf=place(game,-7,-31,()=>{},base);
  return {base,body,legs,scarf};
}
function weather(game) {
  const rain=Array.from({length:60},(_,i)=>{
    const drop=place(game,0,0,g=>line(g,[0,0,-5-(i%7)*2,8+i%8],i%5===0?0xe7d9bb:0xb9d1d2,1,i%4===0?.31:.19));
    return {drop,x:game.random.range(0,1000),y:game.random.range(0,560),v:game.random.range(.64,1.42)};
  });
  const trails=Array.from({length:9},(_,i)=>place(game,0,0,g=>{
    g.lineStyle(1.4,0xcce1da,.43).moveTo(0,0).curveTo(19,-7,42,-4).curveTo(61,0,74+i*2,-6).lineStyle();
  }));
  return {rain,trails};
}
function hud(game) {
  place(game,0,0,g=>{
    box(g,0,0,W,101,ink,.27);
    box(g,0,480,W,60,ink,.96);
    line(g,[29,480,931,480],0x7d918f,1,.58);
    line(g,[29,481,122,481],brass,1,.82);
    diamond(g,45,49,16,0xa77a55,.75);
    diamond(g,45,49,13,0x233541);
    poly(g,[40,45,43,41,47,41,50,45,49,55,42,55],brass);
    box(g,44,46,3,7,0xfff0bf);
    round(g,656,24,276,66,9,ink,.77);
    line(g,[678,65,910,65],0x6d8388,1.4);
    for(const x of [681,723,769,820,914]) diamond(g,x,65,4,0x93a6a5);
    envelope(g,683,38,.52,brass);
  },game.ui);
  words(game,'风灯驿',70,27,37,paper,'left',true);
  words(game,'风暴熄了引灯，把第一封信送到驿站。',31,79,15,0xe2e2d2);
  words(game,'第一封信',706,34,14,paper,'left',true);
  const count=words(game,'引灯  0 / 3',912,35,13,mist,'right');
  const lamps=[723,769,820].map(x=>place(game,x,65,g=>{
    diamond(g,0,0,8,0x302d30);
    diamond(g,0,0,5,brass);
  },game.ui));
  lamps.forEach(l=>l.visible=false);
  const trail=place(game,681,65,g=>{
    dot(g,0,0,5.3,0x263644);
    dot(g,0,0,3.1,0xf5e5c4);
  },game.ui);
  const buttons=[[30,43,'←'],[79,43,'→'],[733,89,'跳跃'],[833,97,'点灯']];
  const highlights=buttons.map(([x,w,label],i)=>{
    place(game,x,491,g=>{
      round(g,0,0,w,37,7,i===3?0x6d4936:0x34464d);
      round(g,1,1,w-2,32,6,i===3?0x9d694a:0x405761);
      line(g,[8,2,w-8,2],i===3?0xe3ac71:0x849b9e,1,.6);
    },game.ui);
    const hi=place(game,x,491,g=>round(g,0,0,w,34,7,0xffe2a7,.28),game.ui);
    hi.visible=false;
    words(game,label,x+w/2,498,i<2?19:15,paper,'center',true);
    return hi;
  });
  words(game,'移动',133,500,14,mist);
  words(game,'空格',723,502,11,mist,'right');
  words(game,'E',920,502,11,0xffe7c5,'right');
  const hint=words(game,'',455,500,16,paper,'center');
  const callout=place(game,0,0,g=>{
    round(g,-74,-13,148,28,7,ink,.94);
    line(g,[-61,13,61,13],brass,1,.65);
  },game.ui);
  const callText=game.text('E  /  点亮引灯',{x:0,y:-10,size:15,color:paper,align:'center',layer:callout});
  callout.visible=false;
  return {hint,count,trail,lamps,highlights,callout,callText};
}

function ignite(game,index) {
  const post=s.lamps[index];
  if(post.lit) return;
  post.lit=true;
  post.glow.visible=true;
  post.marker.visible=false;
  lightGlass(post.cage.graphics,true);
  s.checkpoint=[post.x+29,post.y];
  s.lit++;
  s.hud.lamps[index].visible=true;
  s.hud.count.text='引灯  '+s.lit+' / 3';
  if(index===0) s.bridges[0].visible=true;
  if(index===2) s.bridges[1].visible=true;
  s.notice=index===1?'石脊引灯已亮，迎面的风弱了。':'引灯已亮，栈桥放下了。';
  s.noticeFor=3;
  game.sfx.play('kindle',{pitch:1+index*.11});
  game.burst(post.x+15,post.y-51,{color:0xffbd67,count:18,speed:72,life:.68,size:3,gravity:-34});
  game.tween(post.glow).to({alpha:.45},.1,'quadOut').to({alpha:1},.38,'quadOut');
}
function end(game) {
  s.done=true;
  s.vx=0;
  s.hud.callout.visible=false;
  s.hud.hint.text='第一封信已签收';
  s.hud.highlights.forEach(b=>b.visible=false);
  game.sfx.play('win',{volume:.55});
  game.burst(2543,388,{color:brass,count:18,speed:61,life:.7,size:2.5,gravity:60});
  const letter=place(game,s.x+3,s.y-34,g=>envelope(g,-9,-6,.76));
  game.tween(letter).to({x:2543,y:389,rotation:-12},.25,'quadOut').to({scaleX:.1,scaleY:.1,alpha:0},.15).call(()=>game.remove(letter));
  game.after(.5,()=>{
    s.replay=true;
    place(game,0,0,g=>{
      box(g,0,0,W,H,ink,.68);
      round(g,259,103,442,323,12,0x17242d);
      round(g,270,114,420,301,8,0xeedebd);
      line(g,[291,140,291,124,669,124,669,140],0xa17a5e,1.2);
      line(g,[291,391,291,405,669,405,669,391],0xa17a5e,1.2);
      line(g,[310,307,650,307],0xab8d70,1,.7);
      dot(g,480,174,26,0xa55647);
      dot(g,480,174,21,0xb3604d);
      envelope(g,469,167,.92,0xffebc0);
      for(const x of [451,480,509]) diamond(g,x,329,4,0x936948);
    },game.ui);
    words(game,'第一封信，送到了',480,214,31,0x322c31,'center',true);
    words(game,'山路的三盏引灯重新亮起。',480,264,17,0x705448,'center');
    game.button('再走一趟',{x:480,y:373,width:165,height:37,color:0x394a4d,textColor:paper,size:16,layer:game.ui},()=>game.restart());
  });
}
function readyLamp() {
  return s.lamps.findIndex(post=>!post.lit && Math.abs(post.x+12-s.x)<64 && Math.abs(post.y-s.y)<44);
}
function windAt(x,t) {
  const band=winds.find(([a,b])=>x>a&&x<b);
  if(!band) return 0;
  const [a,b,i,phase]=band;
  const wave=Math.pow(Math.max(0,Math.sin(t*1.92+phase)),2);
  return (17+105*wave)*clamp(Math.min(x-a,b-x)/53,0,1)*(s.lamps[i].lit?.31:1);
}
function move(game,dt,run) {
  const wasGrounded=s.grounded;
  if(wasGrounded) s.coyote=.104;
  else s.coyote-=dt;
  s.wind=windAt(s.x,s.t);
  const aim=run*242;
  s.vx+=(aim-s.vx)*Math.min(1,dt*(wasGrounded?13:8));
  if(s.jumpFor>0 && s.coyote>0) {
    s.vy=-462;
    s.grounded=false;
    s.coyote=0;
    s.jumpFor=0;
    s.land=0;
    game.sfx.play('jump',{volume:.24,pitch:.9});
    game.burst(s.x,s.y,{color:0xa2aca0,count:5,speed:43,life:.26,size:2,gravity:70});
  }
  s.jumpFor-=dt;
  const oldY=s.y;
  const speed=s.vx-s.wind*(s.grounded?.65:1);
  s.x=clamp(s.x+speed*dt,14,END-29);
  s.vy+=1120*dt;
  s.y+=s.vy*dt;
  s.grounded=false;
  if(s.vy>=0) {
    const solid=road.concat(s.lamps[0].lit?[spans[0]]:[],s.lamps[2].lit?[spans[1]]:[]);
    for(const [a,b,y] of solid) {
      if(s.x+7<a || s.x-7>b || oldY>y+.5 || s.y<y) continue;
      if(!wasGrounded && s.vy>125) {
        s.land=.18;
        game.sfx.play('hit',{volume:.12,pitch:.7});
        game.burst(s.x,y-1,{color:0xacb6aa,count:7,speed:49,life:.27,size:2,gravity:120});
      }
      s.y=y;
      s.vy=0;
      s.grounded=true;
      break;
    }
  }
  if(s.y>549) {
    [s.x,s.y]=s.checkpoint;
    s.vx=0;
    s.vy=0;
    s.grounded=true;
    s.jumpFor=0;
    s.assist=0;
    s.land=0;
    s.notice=s.lit?'回到了最近点亮的引灯。':'回到了山路起点。';
    s.noticeFor=2.6;
    game.sfx.play('hurt',{volume:.23});
    game.flash(0xb5c5c5,.22);
    s.cam=clamp(s.x-375,0,END-W);
  }
}
function paintFrame(game,dt,run) {
  const progress=clamp((s.x-169)/(2540-169),0,1);
  const pins=[[169,681],[351,723],[1314,769],[1944,820],[2540,914]];
  for(let i=1;i<pins.length;i++) {
    if(s.x>pins[i][0] && i<pins.length-1) continue;
    const [a,x]=pins[i-1], [b,y]=pins[i];
    s.hud.trail.x=x+(y-x)*clamp((s.x-a)/(b-a),0,1);
    break;
  }
  s.cam+=(clamp(s.x-374,0,END-W)-s.cam)*Math.min(1,dt*5.5);
  game.view.x=s.cam;
  for(const [layer,factor] of s.parallax) layer.x=s.cam*(1-factor);
  for(let i=0;i<s.lamps.length;i++) {
    const l=s.lamps[i];
    if(!l.lit) l.marker.y=l.y-93+Math.sin(s.t*3+i)*4;
  }
  const player=s.player;
  if(Math.abs(run)>.1) s.face=run>0?1:-1;
  const pace=Math.min(1,Math.abs(s.vx)/185);
  s.step+=dt*(5+pace*14);
  s.land=Math.max(0,s.land-dt);
  const bob=s.grounded?Math.abs(Math.sin(s.step))*pace*2:0;
  player.base.x=s.x;
  player.base.y=s.y-bob-1;
  player.base.scaleX=s.face;
  player.base.scaleY=1-s.land*.52;
  player.body.rotation=s.grounded?Math.abs(run)*6:9;
  player.legs[0].rotation=s.grounded?Math.sin(s.step)*pace*30:-28;
  player.legs[1].rotation=s.grounded?-Math.sin(s.step)*pace*30:30;
  s.shadow.x=s.x;
  s.shadow.y=s.y;
  s.shadow.visible=s.grounded;
  s.shadow.scaleX=1+pace*.15;
  const ripple=Math.sin(s.t*17)*3;
  const tail=-23-s.wind*.12-Math.abs(run)*7;
  const g=player.scarf.graphics;
  g.clear();
  poly(g,[2,-1,-8,-2,tail,ripple-3,tail+4,ripple+1,tail-1,ripple+5,-8,3,1,4],0xe9bd84);
  line(g,[-4,0,tail+3,ripple+1],0xffdf9e,1,.85);
  const storm=s.wind/120;
  const rate=game.reducedMotion?.45:1;
  s.skyTime+=dt*rate;
  for(const {drop,x,y,v} of s.weather.rain) {
    drop.x=s.cam+wrap(x-s.skyTime*(142+s.wind*.24)*v,1015)-25;
    drop.y=wrap(y+s.skyTime*250*v,540)-23;
    drop.rotation=storm*19;
  }
  for(const [i,trail] of s.weather.trails.entries()) {
    const travel=wrap(i*133-s.skyTime*(155+storm*60),1080);
    trail.x=s.cam+travel-90;
    trail.y=190+(i*29)%220+Math.sin(s.skyTime+i)*11;
    trail.alpha=storm*.77;
  }
  if(!s.done && progress>.06 && s.grounded && run && s.t>s.nextStep) {
    s.nextStep=s.t+.23;
    if(!game.reducedMotion) game.burst(s.x-s.face*7,s.y-1,{color:0x98a6a3,count:3,speed:22,life:.20,size:1.8,gravity:45});
  }
}
function readControls(game,dt) {
  const p=game.pointer, k=game.keys;
  const bar=p.y>=481&&p.y<540;
  const left=bar&&p.x<77;
  const right=bar&&p.x>=77&&p.x<155;
  const jumpButton=bar&&p.x>=725&&p.x<827;
  const lampButton=bar&&p.x>=827;
  const pointerJump=p.pressed&&jumpButton;
  const jump=pointerJump||k.pressed('space')||k.pressed('up')||k.pressed('w')||k.pressed('pad:a');
  const nearby=readyLamp();
  const l=nearby<0?null:s.lamps[nearby];
  const tapLamp=!!l&&p.y>l.y-120&&p.y<l.y+9&&Math.abs(p.x+s.cam-l.x-15)<41;
  const act=k.pressed('e')||k.pressed('pad:x')||(p.pressed&&(lampButton||tapLamp));
  let run=k.axis().x;
  if(p.down&&!k.axis().x) {
    if(left||right) run=left?-1:1;
    else if(!bar&&!tapLamp&&p.y>120&&Math.abs(p.x+s.cam-s.x)>19) run=p.x+s.cam<s.x?-1:1;
  }
  if(pointerJump&&!run) s.assist=.77;
  if(s.assist>0) {
    s.assist-=dt;
    if(!run) run=s.face;
    else if(left||right) s.assist=0;
  }
  if(jump) s.jumpFor=.14;
  if(act&&nearby>=0) ignite(game,nearby);
  if(act&&nearby<0) {
    s.notice='靠近一盏未亮的引灯，再点灯。';
    s.noticeFor=1.65;
  }
  s.hud.highlights[0].visible=run<-.1;
  s.hud.highlights[1].visible=run>.1;
  s.hud.highlights[2].visible=jump||(p.down&&jumpButton)||k.down('space','up','w','pad:a');
  s.hud.highlights[3].visible=act||(p.down&&lampButton)||k.down('e','pad:x');
  return run;
}
function guidance() {
  const next=readyLamp();
  const call=s.hud.callout;
  call.visible=next>=0;
  if(next>=0) {
    const l=s.lamps[next];
    call.x=clamp(l.x+15-s.cam,82,878);
    call.y=l.y-110;
  }
  let tip;
  if(next>=0) tip='按 E 或点灯，重新点亮'+posts[next][2]+'的引灯。';
  else if(s.noticeFor>0) tip=s.notice;
  else if(s.wind>59) tip='阵风正强，等风弱些再起跳。';
  else if(s.x<455&&!s.lamps[0].lit) tip='到前面的松口引灯旁，点亮它。';
  else if(s.x>2430&&s.lit<3) tip='还有引灯未亮，沿山路回去点亮它。';
  else if(s.x>2390&&s.lit===3) tip='把信送到驿站门前。';
  else if((s.x>872&&s.x<1027)||(s.x>1438&&s.x<1559)) tip='走到断崖边，再起跳。';
  else if(s.lit===3) tip='引灯全部亮起，沿栈桥前往驿站。';
  else tip='沿山路向右，寻找下一盏引灯。';
  if(tip!==s.hud.hint.text) s.hud.hint.text=tip;
}

await Egret.play({
  width:W,height:H,background:0x172b42,seed:1407,
  setup(game) {
    s={x:169,y:422,vx:0,vy:0,face:1,grounded:true,coyote:0,jumpFor:0,cam:0,t:0,skyTime:0,wind:0,land:0,step:0,nextStep:0,assist:0,lit:0,notice:'',noticeFor:0,checkpoint:[169,422],done:false,replay:false};
    game.view.x=0;
    game.view.y=0;
    s.parallax=landscape(game);
    s.bridges=scenery(game);
    s.lamps=posts.map(([x,y])=>lantern(game,x,y));
    s.shadow=place(game,s.x,s.y,g=>oval(g,-16,-3,32,7,ink,.62));
    s.player=courier(game);
    s.weather=weather(game);
    s.hud=hud(game);
    game.sfx.define('kindle',[
      {wave:'triangle',from:392,seconds:.095,volume:.22},
      {wave:'sine',from:587.33,seconds:.115,volume:.23},
      {wave:'sine',from:783.99,seconds:.36,volume:.26}
    ]);
    paintFrame(game,0,0);
    guidance();
  },
  update(dt,game) {
    dt=clamp(dt,0,.064);
    s.t+=dt;
    if(s.done) {
      paintFrame(game,dt,0);
      if(s.replay&&(game.keys.pressed('enter')||game.keys.pressed('r'))) game.restart();
      return;
    }
    s.noticeFor=Math.max(0,s.noticeFor-dt);
    const run=readControls(game,dt);
    const steps=Math.max(1,Math.ceil(dt*120));
    for(let i=0;i<steps;i++) move(game,dt/steps,run);
    paintFrame(game,dt,run);
    guidance();
    if(s.lit===3&&s.x>=2529&&s.grounded) end(game);
  }
});

await Egret.play({
  width: 960, height: 540, background: 0x101828,
  setup(game) {},
  update(dt, game) {}
});


# Windlamp Post, third unedited draft

Both recordings came from the same game module (SHA-256 78927a916130f65524712b5bc9edf820647e0808d1914fd1bd7f999151c372fc). Each began from navigation in a new Windows Chrome for Testing 157.0.8103.6 process with a fresh profile and the original software WebGL2 configuration. Both silent, uncut clips decode to 400 frames at 20 fps, 960 × 540, 20.000 seconds. No page exceptions or failed asset requests were recorded.

**Original comparison protocol.** At 3 s the courier stood left of an unlit lamp. The objective and right-arrow control were visible. Moving right from 3.999 s for the prescribed 1.5 s brought the courier into range; at 4.90 s the lamp revealed its E prompt and the counter still read 0/3. The courier then ran past it and fell into the unbridged gap (5.70 s). By the next input slot he was back at the hut. A short right press at 8.003 s, another 1.5 s movement from 11.999 s and E at 16.004 s did not light the lamp. At 19 s the lamp remained dark and the count was 0/3. The corridor was reachable. This take did not demonstrate lighting or progression past a lit lamp.

**Supplementary playable-route check.** In one separate fresh session, use the visible distance to release the movement key earlier. From 4.004 s hold right for 810 ms. At 7 s the courier stood at the lamp and the prompt said “E / 点亮引灯”, with the count still 0/3 and the gap still empty. Press E at 8.002 s. By 11 s the lamp glowed amber, a wooden bridge filled the gap, the count was 1/3 and the next objective directed the courier to look for another light. From 12.001 s hold right for 320 ms. At 15 and 19 s the courier stood beyond the glowing lamp at the near end of the bridge and the count remained 1/3. This covers approach, confirmed lighting and further movement. The rest of the delivery was not exercised.

The two recordings use identical software and game bytes. The shorter key holds in the second recording are the difference in operation. Its result is separate from the fixed comparison take. No first-time human players participated.

| Run | File | SHA-256 | Compositor frames supplied |
| --- | --- | --- | ---: |
| Original input policy | recorded/opening-20s.mp4 | 7655f116047425deda02deb1641231f2cd3a7d2ce4cecdf962df98f56ee05453 | 1,925 |
| Supplementary | supplemental-recorded/opening-20s.mp4 | 7155be1d82bc307f2c825d7fb788b7fb611eadf23f308f9bab67a1edf897b93b | 1,943 |

Each directory contains its input times and page errors in run.json, encoder readback in video-probe.txt and a decoded screenshot manifest in decoded/manifest.json. The fixed capture recorded/decoded/crossing-first-light.png and gap.png correspond to 4.90 and 5.70 s. The supplementary decoded frames at 7, 11, 15 and 19 s show the three milestones and persistence after release.

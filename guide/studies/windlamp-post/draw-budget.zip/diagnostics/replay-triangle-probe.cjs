// SPDX-License-Identifier: Apache-2.0
// Extract old-entry/draft.zip and new-entry/draft.zip from the first Windlamp Post study.
// node replay-triangle-probe.cjs <A|B> <extracted-draft> <new-output.json> <playwright-dir> <chrome-executable> [nodes|gradients]
// Use a directory with package.json and Playwright installed. Runs one local diagnostic
// session. The original engine and game on disk are read-only. The last rejected count
// includes the attempted part, even though the engine refused before accepting that part.
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const assert = require("node:assert/strict");
const { createServer } = require("node:http");
const { createRequire } = require("node:module");
const { setTimeout: sleep } = require("node:timers/promises");
const sha = (s) => crypto.createHash("sha256").update(s).digest("hex");

function enableObservation() {
  Error.stackTraceLimit = 28;
  const d = (globalThis.__geometryObservations = {
    lastPassed: null,
    failed: null,
    capture: 0,
    radial: [],
  });
  const nodes = new WeakMap();
  let next = 1,
    active = null,
    now = null;
  function tag(node) {
    const site = String(new Error().stack)
      .split("\n")
      .filter((l) => l.includes("/game.mjs:"))
      .slice(0, 6)
      .map((s) =>
        s.trim().replace(/(?:https?:\/\/[^ /]+)?\/game\.mjs/g, "game.mjs"),
      );
    nodes.set(node, { id: next++, site });
  }
  function watch(budget, node, g) {
    if (d.failed) return;
    if (active !== budget) {
      if (now) d.lastPassed = now;
      active = budget;
      now = { capture: ++d.capture, draws: [], sum: 0 };
    }
    const tag = nodes.get(node) || { id: 0, site: [] },
      amount = g.triangleCount,
      before = budget.triangles;
    now.draws.push({
      ...tag,
      amount,
      before,
      after: before + amount,
      visible: node.visible,
      x: node.x,
      y: node.y,
      alpha: node.alpha,
    });
    now.sum += amount;
    if (before + amount > 65536) d.failed = now;
  }
  globalThis.__obsTag = tag;
  globalThis.__obsWatch = watch;
  const seen = new Set();
  globalThis.__obsOutline = (
    graphics,
    add,
    shape,
    points,
    convex,
    fill,
    line,
  ) => {
    if (!fill?.gradient?.radial) return add(shape, points, convex, fill, line);
    const count = () =>
      shape.done.reduce((s, p) => s + p.indices.length, shape.indices.length) /
      3;
    const before = count();
    const accepted = add(shape, points, convex, fill, line);
    const gradient = fill.gradient;
    const entry = {
      node: nodes.get(graphics.owner)?.id,
      x: -gradient.tx / gradient.a,
      y: -gradient.ty / gradient.d,
      radius: 1 / gradient.a,
      triangles: count() - before,
    };
    const key = JSON.stringify(entry);
    if (!seen.has(key)) {
      seen.add(key);
      const site = String(new Error().stack)
        .split("\n")
        .filter((s) => s.includes("/game.mjs:"))
        .slice(0, 5)
        .map((s) =>
          s.trim().replace(/(?:https?:\/\/[^ /]+)?\/game\.mjs/g, "game.mjs"),
        );
      d.radial.push({ ...entry, site });
    }
    return accepted;
  };
}
function patch(s, a, b) {
  assert.equal(s.split(a).length, 2, a);
  return s.replace(a, () => b);
}
async function main() {
  const [arm, directory, output, playwrightDir, exe, id = "gradients"] =
    process.argv.slice(2);
  assert(["A", "B"].includes(arm) && ["gradients", "nodes"].includes(id));
  const chromium = createRequire(path.resolve(playwrightDir, "package.json"))(
    "playwright",
  ).chromium;
  const file = path.resolve(output);
  assert(!fs.existsSync(file));
  const gamePath = path.resolve(directory);
  const orig = fs.readFileSync(path.join(gamePath, "egret2d.js"), "utf8"),
    game = fs.readFileSync(path.join(gamePath, "game.mjs"));
  assert.equal(
    sha(orig),
    "e389e2f457f1bf1ad58cd771804bda7ebfec84f22132b656191034266d07aa01",
  );
  assert.equal(
    sha(game),
    arm === "A"
      ? "9298a15a654510aa6dda1db6aef7d21cb9bcb3b378f891fa9aaa0d9e04274ec8"
      : "12aa8a5dabb8e2f093f67f2f523ea606d6a4b5e34470e7fdaf75f3fb0cd08f44",
  );
  const sprite =
    'this.graphics=new Ri(this),Object.defineProperty(this,"graphics"';
  let code = patch(orig, sprite, "globalThis.__obsTag(this)," + sprite);
  if (id === "gradients")
    code = patch(
      code,
      "_l(this.shape(),e,n,this.edged(this.fill),this.edged(this.line))",
      "globalThis.__obsOutline(this,_l,this.shape(),e,n,this.edged(this.fill),this.edged(this.line))",
    );
  for (const g of ["fe.geometry", "ne.geometry"]) {
    code = patch(
      code,
      "o.geometry(" + g + ")",
      "(globalThis.__obsWatch(o,z," + g + "),o.geometry(" + g + "))",
    );
  }
  assert(
    code.includes("this.triangles=Fn(this.triangles,e.triangleCount,65536)"),
  );
  const source = {
    "/index.html": fs.readFileSync(path.join(gamePath, "index.html")),
    "/game.mjs": game,
    "/egret2d.js": code,
  };
  const server = createServer((req, res) => {
    if (!Object.hasOwn(source, req.url)) {
      res.writeHead(404).end();
      return;
    }
    res
      .writeHead(200, {
        "content-type": req.url.endsWith("html")
          ? "text/html; charset=utf-8"
          : "text/javascript; charset=utf-8",
      })
      .end(source[req.url]);
  });
  await new Promise((ok) => server.listen(0, "127.0.0.1", ok));
  const browser = await chromium.launch({
    executablePath: exe,
    headless: true,
    args: [
      "--use-angle=swiftshader",
      "--enable-unsafe-swiftshader",
      "--ignore-gpu-blocklist",
      "--disable-background-timer-throttling",
      "--disable-renderer-backgrounding",
      "--no-proxy-server",
    ],
  });
  try {
    const context = await browser.newContext({
      viewport: { width: 960, height: 540 },
      locale: "zh-CN",
      deviceScaleFactor: 1,
      reducedMotion: "no-preference",
    });
    await context.addInitScript(enableObservation);
    const page = await context.newPage();
    await page.bringToFront();
    const errors = [];
    page.on("pageerror", (e) => errors.push(e.message));
    const start = Date.now();
    await page.goto(
      "http://127.0.0.1:" + server.address().port + "/index.html",
    );
    if (arm === "B") {
      for (const [at, key] of [
        [4, "d"],
        [8, "e"],
      ]) {
        await sleep(Math.max(0, start + 1000 * at - Date.now()));
        await page.keyboard.down(key);
        await sleep(1500);
        await page.keyboard.up(key);
      }
    }
    await page.waitForFunction(
      () => globalThis.__geometryObservations.failed,
      null,
      { timeout: 6500 },
    );
    const record = await page.evaluate(() => globalThis.__geometryObservations);
    for (const cap of [record.failed, record.lastPassed].filter(Boolean)) {
      assert.equal(cap.sum, cap.draws.at(-1).after);
      assert(
        cap.draws.every(
          (r, i) => r.before === (i === 0 ? 0 : cap.draws[i - 1].after),
        ),
      );
    }
    assert(errors.some((s) => s.startsWith("FRAME_BUDGET_EXCEEDED")));
    fs.writeFileSync(
      file,
      JSON.stringify(
        {
          arm,
          run: id,
          gameSha256: sha(game),
          originalEngineSha256: sha(orig),
          instrumentedEngineSha256: sha(code),
          browser: await browser.version(),
          errors,
          ...record,
        },
        null,
        2,
      ) + "\n",
      { flag: "wx" },
    );
    console.log(
      JSON.stringify({
        arm,
        failed: record.failed.capture,
        prior: record.lastPassed?.sum,
        rejected: record.failed.draws.at(-1),
        top: record.failed.draws
          .toSorted((a, b) => b.amount - a.amount)
          .slice(0, 5)
          .map((r) => [r.amount, r.site.slice(0, 3)]),
      }),
    );
  } finally {
    await browser.close();
    server.close();
  }
}
main().catch((e) => {
  console.error(e);
  process.exitCode = 1;
});

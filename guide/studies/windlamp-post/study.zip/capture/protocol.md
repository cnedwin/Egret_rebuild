# Wind Lantern Post opening capture

Freeze before opening either author output. The Chinese brief asks for a side-view game where a storm has extinguished the mountain lights and a courier must deliver the first letter. This observation concerns the unedited first drafts that the author coordinator supplies.

## Environment and clock

- Run each arm in a separate, fresh Chrome for Testing 157 process on the same Windows computer. Use software WebGL2/ANGLE SwiftShader, a 960 × 540 CSS pixel viewport, scale 1, zh-CN, normal motion, local HTTP and fresh storage. These are browser gameplay observations, not hardware performance measurements.
- Record from the navigation request through 20.000 seconds elapsed, including loading, with no cuts. Collect real browser-compositor images, sample their timestamps at 20 frames per second, and hold the latest image if the compositor supplies none. Export silent H.264, 960 × 540, 400 frames. Sound is not being rated.
- Retain opening captures at 3, 7, 11, 15 and 19 seconds. Verify encoded duration and frame count by decoding. Record all page/script/load failures and input dispatch times. Each arm has one scored recording. Technical capture failures remain in a separate folder with their cause.

## Input policy

At 4, 8, 12 and 16 seconds, at most one visible action may be taken. The first priority is an entry prompt if it blocks play. Once in play, try the first relevant action that the screen explicitly indicates, or an unmistakable visible target. Where there are several equally apparent targets, favor the nearest actionable light to the visible courier, then a visible next-step or station target. Choose an explicit action key over an assumed click. Try the same relevant action again or the next visible step as indicated. A walk command clearly indicated on-screen may be held for 1.5 seconds; a discrete action is pressed once. When no corresponding affordance is visible, wait and report that. After visibly achieving delivery, observe the rest without restarting. A start click alone is distinguished from the first action that changes play.

A disposable route-mapping session may use screenshots and visibly rendered instructions to locate controls before the official recording. Preserve its exploratory screenshots and plan. Do not inspect game source, hidden state, diagnostic hooks, or guess bindings to discover a successful route. Do not rehearse competing routes to select a faster one. Confirm the recorded run actually shows the action and result. Random differences, missing affordances, errors and unsuccessful outcomes remain reportable.

## Comparison

Describe what a new arrival sees, the first visible action offered and attempted, any visible state change at its location, what follows it, and the scene at 19 seconds. Distinguish an instruction, moving scenery, rule-driven feedback, and a changed counter. If persistent visuals or a no-input control cannot establish causality, report the observation and uncertainty. One pair, a scripted driver and no enrolled players cannot establish player comprehension or a general improvement.

Windlamp Post / 风灯驿

old-entry = A; new-entry = B. Each directory contains the original draft.zip, author prompt and raw response, a silent first-20s.mp4 and capture evidence.
Extract either draft.zip to its own directory. Serve that directory over HTTP (for example, python -m http.server 8000), then open http://127.0.0.1:8000/.
A 为旧入口，B 为新入口。每个目录内有未经修改的首稿、提示、原始回答、20 秒无声录像和采集记录。分别解压 draft.zip，以本地静态 HTTP 服务打开。
Original engine and third-party notices are preserved inside each playable archive. The manifest hashes the other archive members.

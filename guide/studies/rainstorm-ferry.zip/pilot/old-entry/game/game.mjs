const W = 960, H = 540, LIMIT = 42;
const ink = 0x0b1c25, paper = 0xe8eef0, quiet = 0x9eb8be;
const gold = 0xffc176, mint = 0x9fe3ce;
const goals = [
  { x: 220, y: 370, mx: 220, my: 314, tag: '第一箱货', task: '搬起货箱', action: '搬起货箱' },
  { x: 664, y: 395, mx: 664, my: 325, tag: '甲板货位', task: '装上渡船', action: '放下货箱' },
  { x: 784, y: 365, mx: 796, my: 264, tag: '驾驶台', task: '驶离码头', action: '解缆启航' }
];
let s;

const clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, n));
const mix = (a, b, t) => a + (b - a) * t;
const fraction = n => n - Math.floor(n);
const noise = n => fraction(Math.sin(n * 127.1 + 311.7) * 43758.5453);
const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);

function rect(g, c, x, y, w, h, a = 1) {
  g.beginFill(c, a).drawRect(x, y, w, h).endFill();
}
function round(g, c, x, y, w, h, r, a = 1) {
  g.beginFill(c, a).drawRoundRect(x, y, w, h, r).endFill();
}
function oval(g, c, x, y, w, h, a = 1) {
  g.beginFill(c, a).drawEllipse(x, y, w, h).endFill();
}
function dot(g, c, x, y, r, a = 1) {
  g.beginFill(c, a).drawCircle(x, y, r).endFill();
}
function poly(g, c, points, a = 1) {
  g.beginFill(c, a).moveTo(points[0], points[1]);
  for (let i = 2; i < points.length; i += 2) g.lineTo(points[i], points[i + 1]);
  g.lineTo(points[0], points[1]).endFill();
}
function line(g, c, w, points, a = 1) {
  g.lineStyle(w, c, a).moveTo(points[0], points[1]);
  for (let i = 2; i < points.length; i += 2) g.lineTo(points[i], points[i + 1]);
  g.lineStyle();
}
function sprite(game, draw, x = 0, y = 0, layer) {
  const node = game.sprite(draw, layer);
  node.x = x;
  node.y = y;
  return node;
}
function label(game, text, x, y, size, color = paper, options = {}) {
  return game.text(text, { x, y, size, color, ...options });
}

function pine(g, x, y, h, c) {
  rect(g, c, x - h * .035, y - h * .76, h * .07, h * .76);
  for (let i = 0; i < 4; i++) {
    const top = y - h + h * i * .18;
    const width = h * (.12 + i * .037);
    poly(g, c, [x, top, x + width, top + h * .41, x + width * .16, top + h * .37,
      x - width, top + h * .43]);
  }
}

function landscape(g) {
  g.beginLinearGradientFill(0, 88, 0, 267, [
    { offset: 0, color: 0x162b3b }, { offset: .64, color: 0x3e5b62 },
    { offset: 1, color: 0x9a9b80 }
  ]).drawRect(0, 0, W, 278).endFill();
  poly(g, 0x203747, [0, 98, 181, 97, 302, 116, 455, 103, 578, 118, 793, 110, 960, 92,
    960, 143, 834, 152, 694, 137, 547, 162, 330, 145, 236, 154, 0, 137]);
  poly(g, 0x4d6669, [0, 164, 170, 170, 275, 159, 420, 176, 576, 163, 765, 177, 960, 157,
    960, 175, 760, 184, 598, 174, 464, 188, 215, 178, 0, 183], .63);
  line(g, 0xc8b291, 1, [480, 193, 529, 193, 552, 190, 658, 190, 694, 193, 770, 193], .48);
  poly(g, 0x60797b, [0, 243, 63, 221, 113, 214, 190, 178, 223, 185, 251, 179, 323, 207,
    366, 203, 447, 226, 509, 233, 586, 221, 650, 191, 687, 206, 734, 208, 809, 237, 960, 213, 960, 270, 0, 270]);
  poly(g, 0x3c5b63, [0, 197, 26, 198, 76, 216, 120, 217, 168, 233, 206, 226, 248, 231,
    290, 245, 345, 244, 410, 258, 544, 260, 628, 241, 659, 236, 709, 239, 769, 229, 822, 206,
    854, 213, 900, 197, 960, 203, 960, 266, 0, 268]);
  poly(g, 0x294751, [0, 225, 37, 219, 81, 229, 116, 236, 161, 239, 208, 252, 292, 257,
    353, 263, 580, 261, 650, 253, 720, 254, 785, 244, 844, 235, 906, 240, 960, 219, 960, 271, 0, 271]);
  for (let i = 0; i < 77; i++) {
    const span = i < 42 ? 0 : 1;
    const x = span ? 742 + noise(i + 4) * 229 : noise(i + 4) * 297;
    const y = span ? 248 - (x - 740) * .061 + noise(i + 599) * 7 : 225 + x * .113 + noise(i + 599) * 7;
    pine(g, x, y, 8 + noise(i + 91) * (span ? 25 : 32), i % 3 ? 0x294751 : 0x34545c);
  }
  g.beginLinearGradientFill(0, 264, 0, 540, [
    { offset: 0, color: 0x54777b }, { offset: .3, color: 0x31575f },
    { offset: 1, color: 0x17353f }
  ]).drawRect(0, 264, W, 276).endFill();
  poly(g, 0x81a0a0, [0, 266, 283, 266, 415, 271, 597, 269, 828, 268, 960, 265, 960, 268,
    767, 276, 610, 273, 416, 275, 223, 270, 0, 271], .35);
  for (let i = 0; i < 123; i++) {
    const x = noise(i + 50) * W, y = 270 + noise(i + 900) * 270;
    const w = 8 + noise(i + 330) * (12 + (y - 260) * .43);
    line(g, i % 3 ? 0x80a1a1 : 0x0c2b37, i % 8 === 0 ? 2 : 1, [x, y, x + w * .42, y - 1, x + w, y], .12 + .1 * noise(i + 8));
  }
  for (let i = 0; i < 16; i++) {
    const y = 270 + i * 4, x = 906 + (noise(i + 60) - .5) * (9 + i);
    rect(g, gold, x, y, 3 + noise(i + 11) * (4 + i * .8), 1, .24 - i * .012);
  }
  poly(g, 0x203d48, [901, 264, 904, 244, 912, 244, 916, 264]);
  rect(g, 0x172e38, 902, 240, 12, 5);
  poly(g, 0x172e38, [899, 240, 908, 234, 917, 240]);
  dot(g, gold, 908, 243, 2.4);
}

function crateArt(g, scale = 1) {
  const face = (c, pts) => poly(g, c, pts.map(v => v * scale));
  face(0x54382d, [-17, -23, 12, -23, 19, -18, 19, 0, -12, 3, -17, -2]);
  face(0xb87740, [-16, -20, 13, -20, 13, 0, -16, 0]);
  face(0xe6ab61, [-16, -20, -10, -26, 19, -26, 13, -20]);
  face(0x885234, [13, -20, 19, -26, 19, -6, 13, 0]);
  face(0xdda25b, [-15, -19, -12, -19, -12, -1, -15, -1]);
  face(0xe1a764, [9, -19, 12, -19, 12, -1, 9, -1]);
  face(0x714b35, [-12, -12, 9, -12, 9, -11, -12, -11]);
  face(0xf6dfab, [-7, -18, 3, -18, 3, -9, -7, -9]);
  face(0x704b35, [-5, -15, 1, -15, 1, -14, -5, -14]);
}

function post(g, x, y, tall = 32) {
  oval(g, 0x0c212a, x - 12, y - 4, 29, 10, .5);
  rect(g, 0x332e2e, x - 5, y - tall, 11, tall);
  rect(g, 0x706055, x - 5, y - tall, 4, tall - 2);
  oval(g, 0xa08a70, x - 6, y - tall - 3, 13, 6);
  rect(g, 0xa38b69, x - 6, y - tall + 8, 13, 3);
  rect(g, 0x8a7258, x - 6, y - tall + 12, 13, 2);
}

function dock(g) {
  poly(g, 0x112c35, [0, 340, 525, 341, 554, 433, 530, 474, 470, 494, 0, 494], .64);
  for (const x of [36, 106, 191, 282, 365, 449, 504]) {
    rect(g, 0x152a31, x, 435, 13, 55 - (x > 480 ? 17 : 0));
    rect(g, 0x3b4140, x, 440, 5, 43 - (x > 480 ? 13 : 0));
    line(g, 0x648389, 1, [x - 9, x > 480 ? 477 : 490, x + 25, x > 480 ? 477 : 490], .53);
  }
  poly(g, 0x332d30, [0, 432, 526, 430, 526, 448, 474, 470, 0, 470]);
  poly(g, 0x65574b, [0, 304, 463, 304, 526, 329, 526, 433, 473, 453, 0, 453]);
  for (let i = 0; i < 15; i++) {
    const y = 305 + i * 10;
    const edge = y < 329 ? 463 + (y - 304) * 2.52 : y > 433 ? 526 - (y - 433) * 2.65 : 526;
    line(g, 0x2b2b2c, 1, [0, y, edge - 2, y], .79);
    line(g, 0xbaa080, 1, [0, y + 2, edge - 4, y + 2], .43);
    for (let j = 0; j < 5; j++) {
      const x = j * 104 + noise(i * 8 + j + 1) * 58;
      if (x + 29 < edge) {
        rect(g, 0x8f7d65, x, y + 3, 8 + noise(i + j + 17) * 20, 4, .34);
        dot(g, 0x493e38, x - 3, y + 6, 1.1);
      }
    }
  }
  line(g, 0xb89a70, 2, [0, 451, 473, 451, 525, 432], .83);
  for (let x = 34; x < 474; x += 48) rect(g, 0xb79b6f, x, 444, 27, 2, .52);
  oval(g, 0x3e3936, 138, 345, 135, 48, .43);
  oval(g, 0xd7a96e, 178, 348, 84, 36, .15);
  for (const [x, y] of [[195, 350], [245, 350], [195, 382], [245, 382]]) {
    line(g, 0xe3b274, 1.5, [x + (x < 220 ? 7 : -7), y, x, y, x, y + (y < 360 ? 6 : -6)]);
  }
  post(g, 499, 353, 20);
  post(g, 499, 433, 22);
  post(g, 108, 435, 25);
  for (let i = 0; i < 4; i++) oval(g, 0xd1ab78, 455 + i * 2, 403 + i * 2, 33 - i * 4, 14 - i * 3, .15 + i * .12);
}

function shed(g) {
  poly(g, 0x2d2a2a, [0, 305, 104, 293, 156, 328, 127, 345, 0, 354], .62);
  poly(g, 0x4e5148, [0, 249, 107, 250, 107, 327, 0, 330]);
  poly(g, 0x353e3a, [107, 250, 131, 264, 130, 312, 107, 327]);
  for (let x = 5; x < 106; x += 10) line(g, 0x222f31, 1, [x, 253, x, 328], .48);
  poly(g, 0x1c3239, [0, 201, 70, 201, 137, 252, 119, 261, 0, 252]);
  poly(g, 0x344d52, [0, 200, 71, 200, 132, 248, 0, 244]);
  for (let x = 0; x < 73; x += 12) line(g, 0x547075, 1.4, [x, 201, x + 51, 245], .48);
  rect(g, 0x242e2e, 16, 274, 27, 55);
  rect(g, 0xa3744d, 21, 278, 18, 22);
  rect(g, 0xf7c581, 23, 280, 14, 17);
  rect(g, 0x79583e, 29, 280, 2, 17);
  rect(g, 0xdba36b, 23, 287, 14, 1);
  rect(g, 0x252e2c, 50, 273, 49, 20);
  rect(g, 0xa89471, 50, 292, 49, 1);
  oval(g, 0xffb56b, 112, 301, 71, 28, .12);
  rect(g, 0x283536, 144, 264, 4, 68);
  line(g, 0x424d46, 3, [146, 267, 146, 260, 158, 260, 161, 266]);
  for (let i = 4; i >= 0; i--) dot(g, 0xffb66f, 161, 271, 5 + i * 5, .045);
  poly(g, 0x232d2f, [153, 269, 157, 264, 165, 264, 170, 269]);
  round(g, 0xffd39b, 156, 269, 11, 7, 2);
  for (const [x, y, size] of [[110, 344, .68], [135, 351, .56]]) {
    g.moveTo(x, y);
    oval(g, 0x17262b, x - 11, y - 3, 22, 6, .48);
    rect(g, 0x54413a, x - 9, y - 21 * size, 18, 21 * size);
    oval(g, 0x8d7658, x - 9, y - 24 * size, 18, 6 * size);
    rect(g, 0x9a8266, x - 9, y - 8, 18, 2, .76);
  }
}

function ramp(g) {
  poly(g, 0x0f2832, [505, 365, 629, 364, 636, 399, 509, 412], .66);
  poly(g, 0x333e42, [503, 355, 626, 357, 630, 395, 503, 400]);
  poly(g, 0x827967, [505, 355, 625, 357, 624, 389, 505, 394]);
  for (let x = 509; x < 625; x += 9) {
    line(g, 0x403d37, 1, [x, 355, x, 394 - (x - 505) * .04], .77);
    line(g, 0xad9b7e, 1, [x + 1, 359, x + 1, 388 - (x - 505) * .03], .66);
  }
  line(g, 0xc4ab84, 2, [505, 356, 626, 358]);
  line(g, 0xc4ab84, 2, [505, 394, 625, 390]);
  for (let i = 0; i < 3; i++) {
    line(g, gold, 2, [535 + i * 23, 371, 541 + i * 23, 376, 535 + i * 23, 381], .7);
  }
}

function ferry(g) {
  oval(g, 0x102f38, -126, -30, 274, 89, .52);
  oval(g, 0x95baba, -117, -24, 257, 67, .17);
  poly(g, 0x172f38, [-114, -36, -77, -58, 57, -58, 106, -42, 135, -18, 126, 13,
    95, 43, 53, 53, -80, 53, -107, 40, -116, 22]);
  poly(g, 0x9a5241, [-113, 2, -85, 22, 65, 25, 111, 8, 134, -18, 126, 12, 95, 41,
    52, 49, -81, 49, -105, 38, -115, 21]);
  poly(g, 0x3c6e71, [-114, -37, -76, -57, 57, -57, 106, -42, 135, -18, 114, 9,
    77, 30, -84, 31, -109, 18]);
  poly(g, 0x697f78, [-105, -32, -73, -51, 53, -51, 101, -37, 124, -17, 107, 1,
    75, 24, -82, 24, -102, 14]);
  for (let i = 0; i < 7; i++) {
    const y = -43 + i * 10;
    const left = y < -30 ? -74 : -97;
    line(g, 0x324f4e, 1, [left, y, 101 - Math.abs(y + 11) * .86, y], .52);
    line(g, 0x9dafa0, 1, [left + 3, y + 1, 80 - Math.abs(y + 11) * .38, y + 1], .31);
  }
  line(g, 0xf0c38c, 2, [-109, 19, -85, 31, 77, 30, 113, 10, 133, -15], .86);
  line(g, 0xa2c0ba, 2, [-111, -38, -76, -58, 53, -58, 105, -43, 131, -23], .88);
  line(g, 0xbad0c5, 2, [-81, 20, -38, 20, -1, 20, 40, 20, 77, 19, 115, -3], .77);
  for (const [x, y] of [[-84, 31], [-41, 31], [0, 31], [41, 31], [77, 29], [107, 13], [-76, -50], [-26, -52], [103, -38]]) {
    line(g, 0x254549, 3, [x, y, x, y - 13]);
    line(g, 0xb1bbb0, 1, [x - 1, y - 2, x - 1, y - 13]);
  }
  for (const x of [-70, -19, 34]) {
    oval(g, 0x142a32, x - 10, 33, 17, 14);
    oval(g, 0x596567, x - 6, 36, 9, 7);
    oval(g, 0x283941, x - 4, 37, 5, 5);
  }
  round(g, 0x29494a, -82, -4, 37, 25, 4, .7);
  for (const x of [-81, -48]) {
    line(g, gold, 2, [x, 6, x, -4, x + (x < -60 ? 8 : -8), -4], .86);
    line(g, gold, 2, [x, 12, x, 21, x + (x < -60 ? 8 : -8), 21], .86);
  }
  poly(g, 0x273e42, [-6, -24, 62, -26, 81, -8, 6, 1, -19, -14], .48);
  poly(g, 0x82958a, [-1, -79, 62, -76, 60, -29, -1, -26]);
  poly(g, 0x547a76, [62, -76, 78, -66, 76, -38, 60, -29]);
  poly(g, 0xc5c9aa, [-12, -80, 4, -97, 66, -93, 82, -76, 65, -68, -10, -72]);
  poly(g, 0x3b5d60, [-12, -76, 65, -72, 82, -79, 82, -73, 65, -66, -12, -70]);
  for (const [x, w] of [[5, 21], [30, 24]]) {
    round(g, 0x304a4e, x, -64, w, 24, 2);
    rect(g, 0xffc581, x + 2, -62, w - 4, 15);
    poly(g, 0xffe0a3, [x + 2, -61, x + 10, -61, x + 5, -48, x + 2, -48]);
    rect(g, 0xa77a50, x + 2, -47, w - 4, 4);
  }
  poly(g, 0xb68354, [63, -64, 74, -61, 74, -49, 63, -45]);
  line(g, 0x2a474c, 3, [15, -93, 15, -121]);
  line(g, 0x8aa3a0, 1, [15, -119, 34, -119]);
  dot(g, mint, 15, -122, 2.5);
  rect(g, 0x29454a, 45, -105, 8, 14);
  rect(g, 0x182f36, 44, -106, 11, 3);
  dot(g, 0xc55b46, -16, -29, 8);
  dot(g, 0xe8ddba, -16, -29, 5.6);
  dot(g, 0x536e69, -16, -29, 3.3);
  dot(g, mint, 112, -18, 3);
  dot(g, mint, 112, -18, 10, .13);
}

function person(g, stride, facing, carrying, moving) {
  g.clear();
  oval(g, 0x15282b, -16, -4, 32, 10, .55);
  const step = moving ? Math.sin(stride) * 5 : 0;
  const bob = moving ? Math.abs(Math.sin(stride)) * 1.6 : 0;
  line(g, 0x1c3037, 5, [-5, -12, -5 + step * facing, -2]);
  line(g, 0x293f43, 5, [5, -13, 5 - step * facing, -2]);
  line(g, 0x111f2a, 3, [-6 + step * facing, -1, -1 + step * facing, -1]);
  line(g, 0x111f2a, 3, [3 - step * facing, -1, 8 - step * facing, -1]);
  poly(g, 0xc98441, [-10, -27 - bob, 7, -28 - bob, 12, -17, 10, -10, -11, -10, -12, -19]);
  poly(g, 0xf8ba5d, [-9, -26 - bob, 6, -27 - bob, 8, -13, -10, -13]);
  line(g, 0xf9e3af, 1.4, [-8, -15, 8, -15]);
  line(g, 0x8c5a35, 1, [1, -24, 1, -11]);
  dot(g, 0xf6d0a1, facing * 2, -30 - bob, 5);
  poly(g, 0xf0ad55, [-10, -31 - bob, -8, -38 - bob, -3, -41 - bob, 4, -40 - bob,
    8, -36 - bob, 10, -31 - bob]);
  line(g, 0x573e35, 2, [-10, -32 - bob, 11, -32 - bob]);
  dot(g, 0x423c35, facing * 5, -30 - bob, 1);
  if (carrying) {
    const offset = facing * 9;
    line(g, 0xd6964e, 4, [facing * -6, -23, offset, -17]);
    round(g, 0x9d5c36, offset - 9, -25 - bob, 19, 14, 2);
    rect(g, 0xcd8d51, offset - 8, -24 - bob, 17, 3);
    rect(g, 0xe9c58a, offset - 2, -20 - bob, 6, 5);
    line(g, 0xe9ad59, 3, [facing * 5, -23, facing * 11, -15, facing * 15, -16]);
  } else {
    line(g, 0xe3a353, 4, [facing * 8, -24, facing * (10 - step / 3), -15]);
  }
}

function hud(game) {
  const ui = game.ui;
  sprite(game, g => {
    rect(g, 0x0c1d28, 0, 0, W, 100);
    rect(g, 0x5b7d84, 24, 99, 912, 1, .66);
    rect(g, gold, 25, 24, 3, 53);
    rect(g, 0x46616a, 291, 27, 1, 45, .66);
    round(g, 0x162e3a, 704, 18, 232, 63, 8);
    line(g, quiet, 1, [721, 35, 728, 29, 725, 36, 733, 36, 722, 45, 725, 39, 719, 39, 721, 35], .8);
    round(g, 0x101f28, 24, 470, 912, 52, 8, .97);
    rect(g, 0x47626a, 38, 470, 884, 1, .8);
    rect(g, 0x42606b, 354, 482, 1, 27, .6);
  }, 0, 0, ui);
  label(game, '青岚河 · 北岸', 40, 22, 12, gold, { bold: true });
  label(game, '暴雨渡口', 38, 36, 40, paper, { bold: true });
  s.steps = goals.map((goal, i) => {
    const x = 327 + i * 119;
    if (i < 2) sprite(game, g => line(g, 0x68838a, 1.4, [0, -3, 4, 0, 0, 3], .7), x + 98, 49, ui);
    return label(game, goal.task, x + 24, 40, 16, quiet, { bold: true });
  });
  s.stepDots = sprite(game, () => {}, 0, 0, ui);
  s.weatherText = label(game, '距暴雨', 743, 28, 14, quiet, { bold: true });
  s.clock = label(game, '00:42', 919, 24, 27, gold, { align: 'right', bold: true });
  sprite(game, g => rect(g, 0x304d56, 0, 0, 198, 4), 720, 65, ui);
  s.meter = sprite(game, () => {}, 720, 65, ui);
  label(game, 'WASD / 方向键   移动     E   交互', 41, 480, 14, paper, { bold: true });
  label(game, '也可点击场景目标移动并交互', 41, 499, 12, quiet);
  s.hint = label(game, '', 374, 486, 16, paper, { bold: true });
  s.actionBg = sprite(game, () => {}, 757, 479, ui);
  s.actionText = label(game, '', 835, 485, 16, ink, { align: 'center', bold: true });
}

function refreshHud() {
  const phase = Math.min(s.stage, 2), ready = s.stage < 3 && distance(s.player, goals[phase]) <= 29;
  const warn = s.left <= 12;
  const seconds = Math.max(0, Math.ceil(s.left));
  const status = s.result || (s.stage === 3 ? 'sailing' : '');
  const current = `${s.stage}|${ready}|${seconds}|${s.notice}|${status}`;
  if (current === s.hudKey) return;
  s.hudKey = current;
  s.steps.forEach((step, i) => { step.color = i < s.stage ? mint : i === s.stage ? gold : quiet; });
  const g = s.stepDots.graphics.clear();
  for (let i = 0; i < goals.length; i++) {
    const x = 334 + i * 119;
    if (i < s.stage) {
      dot(g, mint, x, 49, 8);
      line(g, ink, 1.6, [x - 4, 49, x - 1, 52, x + 4, 46]);
    } else {
      dot(g, i === s.stage ? gold : 0x54717a, x, 49, 7);
      dot(g, 0x102631, x, 49, i === s.stage ? 3 : 5.5);
    }
  }
  s.weatherText.text = status === 'sailing' ? '渡船离岸中' : status === 'won' ? '已离岸' : status === 'lost' ? '暴雨已至' : '距暴雨';
  s.clock.text = `00:${String(seconds).padStart(2, '0')}`;
  s.clock.color = warn ? 0xff987b : gold;
  rect(s.meter.graphics.clear(), warn ? 0xff987b : gold, 0, 0, 198 * s.left / LIMIT, 4);
  const hints = ['从货栈前搬起标记的箱子', '沿跳板把货箱送到甲板货位', '货箱已固定，前往驾驶台'];
  s.hint.text = s.notice || (status === 'sailing' ? '缆绳已解开，渡船正在离开泊位' : status ? '按 R 或点击按钮再玩一次' : hints[phase]);
  const action = ['前往货箱', '前往货位', '前往驾驶台'];
  s.actionText.text = status === 'sailing' ? '离岸中…' : status ? '再玩一次' : ready ? goals[phase].action : action[phase];
  const button = s.actionBg.graphics.clear();
  round(button, status === 'sailing' ? 0x708c8f : ready || status ? gold : 0xb6d0cb, 0, 0, 161, 34, 6);
  line(button, 0xf5e2b8, 1, [8, 2, 152, 2], .7);
}

function zone(x) {
  return x <= 514 ? 0 : x <= 620 ? 1 : 2;
}
const banks = [[339, 437], [359, 396], [348, 409]];

function routeTo(point, interact) {
  const from = zone(s.player.x), to = zone(point.x), route = [];
  if (from < to) {
    if (from === 0) route.push({ x: 502, y: 378 });
    if (to === 2) route.push({ x: 628, y: 378 });
  } else if (from > to) {
    if (from === 2) route.push({ x: 628, y: 378 });
    if (to === 0) route.push({ x: 502, y: 378 });
  }
  route.push(point);
  s.route = route;
  s.autoAction = interact;
}

function startClock(game) {
  if (s.started) return;
  s.started = true;
  s.wind = game.sfx.loop('wind', { volume: .1 });
}

function act(game, auto) {
  if (s.stage >= 3 || s.result) return;
  startClock(game);
  const goal = goals[s.stage];
  if (distance(s.player, goal) > 29) {
    if (auto) routeTo(goal, true);
    else {
      s.notice = '靠近标记后按 E';
      s.noticeTime = 1.3;
      game.sfx.play('click', { volume: .22 });
    }
    return;
  }
  s.route = [];
  s.autoAction = false;
  s.notice = '';
  s.stage++;
  if (s.stage === 1) {
    game.sfx.play('pickup');
    game.burst(220, 352, { color: gold, count: 8, life: .31, speed: 43, size: 2 });
  }
  if (s.stage === 2) {
    s.drop = .28;
    game.sfx.play('thud');
    game.burst(664, 391, { color: mint, count: 13, life: .4, speed: 55, size: 2 });
    game.shake(2, .13);
  }
  if (s.stage === 3) {
    s.motor = game.sfx.loop('hum', { volume: .27, pitch: .57 });
    game.sfx.play('horn');
    game.shake(3, .24);
  }
}

function pointer(game) {
  if (!game.pointer.pressed) return;
  const { x, y } = game.pointer;
  if (x >= 757 && x <= 918 && y >= 479 && y <= 513 && s.stage < 3) {
    act(game, true);
    return;
  }
  if (y < 118 || y >= 461) return;
  const goal = goals[s.stage];
  if ((Math.abs(x - goal.mx) < 55 && y >= goal.my - 15 && y <= goal.y + 15) || distance({ x, y }, goal) < 33) {
    act(game, true);
    return;
  }
  if (x < 144 || x > 817 || y < 338) return;
  const [lo, hi] = banks[zone(x)];
  if (y >= lo - 3 && y <= hi + 4) {
    startClock(game);
    routeTo({ x, y: clamp(y, lo, hi) }, false);
  }
}

function walk(dt, game) {
  pointer(game);
  if (game.keys.pressed('e', 'space', 'enter', 'pad:a')) act(game, false);
  const axis = game.keys.axis();
  let dx = axis.x, dy = axis.y, cap = Infinity;
  if (Math.hypot(dx, dy) > .13) {
    startClock(game);
    s.route = [];
    s.autoAction = false;
  } else if (s.route.length) {
    const point = s.route[0];
    dx = point.x - s.player.x;
    dy = point.y - s.player.y;
    cap = Math.hypot(dx, dy);
    if (cap <= 1) s.route.shift();
  } else {
    dx = 0;
    dy = 0;
  }
  if (s.autoAction && distance(s.player, goals[s.stage]) <= 29) {
    act(game, true);
    s.walking = false;
    return;
  }
  const length = Math.hypot(dx, dy);
  const p = s.player;
  const previousX = p.x, previousY = p.y;
  if (length > 0) {
    const speed = s.stage === 1 ? 144 : 201;
    const step = Math.min(cap, speed * dt * (cap === Infinity ? Math.min(1, length) : 1));
    const [lo, hi] = banks[zone(p.x)];
    p.y = clamp(p.y + dy / length * step, lo, hi);
    const next = clamp(p.x + dx / length * step, 144, 817);
    const [nextLo, nextHi] = banks[zone(next)];
    if (p.y >= nextLo && p.y <= nextHi) p.x = next;
    if (Math.abs(p.x - previousX) > .05) s.facing = p.x > previousX ? 1 : -1;
  }
  const motion = Math.hypot(p.x - previousX, p.y - previousY);
  s.walking = motion > .05;
  if (s.walking) {
    const before = Math.floor(s.stride / Math.PI);
    s.stride += motion * .17;
    if (Math.floor(s.stride / Math.PI) !== before) {
      game.sfx.play('pop', { volume: zone(p.x) === 1 ? .12 : .065, pitch: .54 + noise(before) * .28 });
    }
  }
}

function weather(dt, game) {
  const storm = 1 - s.left / LIMIT;
  const t = s.time;
  const rain = s.rain.graphics.clear();
  const water = s.water.graphics.clear();
  s.dim.alpha = .04 + storm * .28;
  for (let i = 0; i < 39; i++) {
    const x = fraction(noise(i + 580) - t * (.011 + .009 * noise(i))) * 1120 - 100;
    const y = 275 + noise(i + 319) * 229;
    const w = 11 + noise(i + 81) * (y - 242) * .48;
    line(water, 0x9dbeb9, i % 9 === 0 ? 1.6 : .8, [x, y, x + w * .5, y - 1, x + w, y], .1 + .11 * noise(i + 24));
  }
  for (let i = 0; i < 28 + storm * 109; i++) {
    const speed = .55 + noise(i + 346) * .49;
    const x = fraction(noise(i + 564) - t * (.07 + storm * .14) * speed) * 1020 - 20;
    const y = 102 + fraction(noise(i + 247) + t * .72 * speed) * 362;
    const size = (5 + 14 * storm) * speed;
    line(rain, i % 4 ? 0xaac5cc : 0xd3e0df, .8, [x, y, x - size * (.22 + storm * .46), y + size], .14 + storm * .24);
  }
  for (let i = 0; i < 7 + storm * 15; i++) {
    const p = fraction(t * .77 + noise(i + 31));
    const x = noise(i + 890) * 960, y = 277 + noise(i + 730) * 180;
    if (x < 526 && y > 306) continue;
    const width = 2 + p * 13;
    line(water, 0xbad6d2, .8, [x - width, y, x, y + p * 2, x + width, y], (1 - p) * (.11 + storm * .22));
  }
  if (s.wind) s.wind.volume = .1 + .23 * storm;
  if (s.started && s.stage < 3 && !s.result && s.left < s.nextThunder) {
    s.nextThunder -= 7;
    if (!game.reducedMotion) game.flash(0xb8d2dc, .16);
    game.sfx.play('thunder');
    game.shake(2, .16);
  }
}

function marker(game) {
  const g = s.marker.graphics.clear();
  s.markerText.visible = s.stage < 3 && !s.result;
  if (!s.markerText.visible) return;
  const goal = goals[s.stage];
  const pulse = .5 + .5 * Math.sin(s.time * 4);
  const c = s.stage === 1 ? mint : gold;
  const y = goal.my;
  const target = s.stage === 0 ? goal.y - 25 : s.stage === 1 ? goal.y - 5 : goal.y - 12;
  line(g, c, 1, [goal.mx, y + 13, goal.mx, y + 23, goal.x, target], .38 + pulse * .34);
  oval(g, c, goal.x - 15 - pulse * 3, goal.y - 3, 30 + pulse * 6, 8, .21 + pulse * .12);
  poly(g, c, [goal.mx - 4, y + 12, goal.mx + 4, y + 12, goal.mx, y + 17]);
  round(g, c, goal.mx - 44, y - 13, 88, 26, 6);
  round(g, 0x112831, goal.mx - 43, y - 12, 86, 24, 5, .96);
  dot(g, c, goal.mx - 33, y, 2.5, .52 + pulse * .48);
  s.markerText.text = goal.tag;
  s.markerText.x = goal.mx + 4;
  s.markerText.y = y;
  s.markerText.color = c;
}

function render(dt, game) {
  const t = s.time;
  const sailing = s.stage === 3;
  const progress = clamp(s.depart / 3.6, 0, 1);
  const shift = 272 * progress * (.32 + .68 * progress);
  const lift = 56 * progress;
  const roll = Math.sin(t * 2.6) * (sailing ? 1.18 : .48) - progress * 4;
  const fy = 381 - lift + Math.sin(t * 2.2) * (sailing ? 2.5 : .9);
  const fx = 727 + shift;
  s.boat.x = fx;
  s.boat.y = fy;
  s.boat.rotation = roll;
  const angle = roll * Math.PI / 180;
  const cos = Math.cos(angle), sin = Math.sin(angle);
  const wake = s.wake.graphics.clear();
  if (sailing) {
    const churn = Math.min(1, progress * 9);
    for (let i = 0; i < 30; i++) {
      const p = fraction(t * .65 + noise(i + 70));
      const x = fx - 110 - p * (65 + shift * .46) - noise(i + 2) * 21;
      const y = fy + 19 + (noise(i + 43) - .45) * (14 + p * 68) + p * 18;
      const size = 5 + (9 + p * 28) * noise(i + 227);
      line(wake, i % 3 ? 0xb4d2c6 : 0xe5dbc0, p < .28 ? 2.3 : 1, [x - size, y + 2, x, y, x + size * .46, y - 1], churn * (1 - p) * .57);
    }
    const bridge = clamp(s.depart * 2.8, 0, 1);
    s.bridge.scaleX = 1 - bridge * .64;
    s.bridge.alpha = 1 - bridge * .24;
  }
  const rope = s.rope.graphics.clear();
  if (!sailing) {
    line(rope, 0x242e2e, 3.5, [499, 339, 527, 345, 570, 351, 617, fy - 39], .9);
    line(rope, 0xcfad7e, 1.8, [499, 338, 527, 344, 570, 350, 617, fy - 40]);
  } else if (s.depart < .42) {
    const p = s.depart / .42;
    line(rope, 0xcfad7e, 2, [499, 338, 521 - p * 8, 349 + p * 13, 617 - p * 97, 342 + p * 40], 1 - p);
  }
  s.crate.visible = s.stage !== 1;
  s.drop = Math.max(0, s.drop - dt);
  if (s.stage >= 2) {
    s.crate.x = fx - 63 * cos - 14 * sin;
    s.crate.y = fy - 63 * sin + 14 * cos - s.drop * 23;
    s.crate.rotation = roll;
  }
  if (sailing) {
    const px = s.player.x - 727, py = s.player.y - 381;
    s.hero.x = fx + px * cos - py * sin;
    s.hero.y = fy + px * sin + py * cos;
  } else {
    s.hero.x = s.player.x;
    s.hero.y = s.player.y;
  }
  const pose = `${Math.floor(s.stride * 3)}|${s.facing}|${s.stage}|${s.walking}`;
  if (pose !== s.pose) {
    person(s.hero.graphics, s.stride, s.facing, s.stage === 1, s.walking && !sailing && !s.result);
    s.pose = pose;
  }
  weather(dt, game);
  marker(game);
  refreshHud();
}

function finish(game, won) {
  s.result = won ? 'won' : 'lost';
  s.walking = false;
  s.notice = '';
  s.pose = '';
  if (s.motor) s.motor.volume = .07;
  game.sfx.play(won ? 'win' : 'lose', { volume: .65 });
  const ui = game.ui;
  sprite(game, g => {
    rect(g, 0x091821, 0, 100, 960, 361, .47);
    round(g, 0x152e39, 267, 151, 426, 238, 12);
    line(g, won ? mint : gold, 2, [284, 152, 676, 152], .83);
    dot(g, won ? mint : gold, 480, 185, 13, .2);
    if (won) line(g, mint, 2.5, [474, 185, 479, 190, 487, 181]);
    else line(g, gold, 2, [483, 177, 475, 185, 482, 185, 477, 193]);
  }, 0, 0, ui);
  label(game, won ? '渡船已离岸' : '暴雨到了', 480, 205, 38, paper, { align: 'center', bold: true });
  const elapsed = Math.max(1, Math.ceil(LIMIT - s.left));
  label(game, won ? `第一箱货已装船 · 用时 ${elapsed} 秒` : s.stage === 2 ? '货箱已装船，渡船仍停在码头。' : '渡船仍在等第一箱货。',
    480, 264, 16, quiet, { align: 'center' });
  game.button('再玩一次', { x: 480, y: 332, width: 174, height: 40, color: won ? mint : gold,
    textColor: ink, size: 17, layer: ui }, () => game.restart());
}

await Egret.play({
  width: W, height: H, background: ink,
  setup(game) {
    s = { player: { x: 307, y: 409 }, stage: 0, left: LIMIT, time: 0, started: false, route: [],
      facing: -1, stride: 0, depart: 0, drop: 0, notice: '', noticeTime: 0, nextThunder: 13 };
    game.sfx.define('pickup', [{ wave: 'triangle', from: 440, to: 588, seconds: .11, volume: .35 },
      { wave: 'sine', from: 660, to: 820, seconds: .13, volume: .19 }]);
    game.sfx.define('thud', { wave: 'triangle', from: 146, to: 46, seconds: .22, volume: .48, decay: 3 });
    game.sfx.define('horn', [{ wave: 'triangle', from: 139, to: 125, seconds: .78, volume: .32 },
      { wave: 'sine', from: 92, to: 86, seconds: .38, volume: .2 }]);
    game.sfx.define('thunder', { wave: 'noise', from: 100, to: 43, seconds: .75, volume: .22, decay: 4 });
    sprite(game, landscape);
    s.water = sprite(game, () => {});
    s.wake = sprite(game, () => {});
    sprite(game, dock);
    s.bridge = sprite(game, g => {
      g.moveTo(-503, 0);
      const draw = { beginFill: (...args) => { g.beginFill(...args); return draw; },
        moveTo: (x, y) => { g.moveTo(x - 503, y); return draw; },
        lineTo: (x, y) => { g.lineTo(x - 503, y); return draw; },
        lineStyle: (...args) => { g.lineStyle(...args); return draw; },
        endFill: () => { g.endFill(); return draw; } };
      ramp(draw);
    }, 503);
    s.rope = sprite(game, () => {});
    s.boat = sprite(game, ferry, 727, 381);
    label(game, '青岚', -31, 33, 11, 0xffe3ad, { layer: s.boat, bold: true });
    sprite(game, shed);
    label(game, '北岸货栈', 74, 276, 10, 0xe8d1a5, { layer: 'world', align: 'center', bold: true });
    s.crate = sprite(game, crateArt, 220, 370);
    s.hero = sprite(game, () => {}, s.player.x, s.player.y);
    s.dim = sprite(game, g => rect(g, 0x0c2031, 0, 99, W, 371));
    s.rain = sprite(game, () => {});
    s.marker = sprite(game, () => {});
    s.markerText = label(game, '', 0, 0, 14, gold, { layer: 'world', align: 'center', baseline: 'middle', bold: true });
    hud(game);
    render(0, game);
  },
  update(dt, game) {
    if (game.keys.pressed('r') || (s.result && game.keys.pressed('enter'))) {
      game.restart();
      return;
    }
    dt = Math.min(dt, .05);
    s.time += dt;
    if (!s.result && s.stage < 3) {
      if (s.noticeTime > 0) {
        s.noticeTime -= dt;
        if (s.noticeTime <= 0) s.notice = '';
      }
      if (s.started) s.left = Math.max(0, s.left - dt);
      if (s.left <= 0) finish(game, false);
      else walk(dt, game);
    }
    if (s.stage === 3 && !s.result) {
      s.depart += dt;
      s.motor.pitch = .57 + Math.min(.65, s.depart * .21);
      if (s.depart >= 3.6) finish(game, true);
    }
    if (s.result && game.pointer.pressed && game.pointer.x >= 757 && game.pointer.x <= 918 &&
        game.pointer.y >= 479 && game.pointer.y <= 513) {
      game.restart();
      return;
    }
    render(dt, game);
  }
});

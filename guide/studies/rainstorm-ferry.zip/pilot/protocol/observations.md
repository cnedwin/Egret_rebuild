# Rainstorm Ferry | opening evidence for the first blind pair

| Blind label | First progress | First box reaches the ferry | Ferry leaves after loading |
| --- | --- | --- | --- |
| cobalt | 4.000 s, clicked the visible "搬起木箱" button. At 4.300 s the worker moved toward the crate. By 7 s the worker was carrying it and the current task read "固定货箱". | At 8.003 s clicked the visible "固定货箱" button. By 11 s the first box was in the deck slot, the loading step was checked and the "解开缆绳" task was visible. | Clicked "解开缆绳" at 12.002 s and "启动渡船" at 15.999 s using the changing task button. By 18 s the boat began to separate from the dock with the box aboard. By 19 s the gap and wake were visible, and all four steps were checked. |
| juniper | 4.004 s, clicked the marked crate using the scene-target instruction. At 4.300 s the worker was beside the crate. At 4.700 s the crate was in the worker's arms and the deck slot was marked. | At 8.002 s clicked the marked "甲板货位". By 11 s the box was on the deck, loading was checked and "驾驶台" was the next marked target. | At 12.000 s clicked the marked helm. By 13.500 s there was water between the moving ferry and the dock, with the box still aboard. By 19 s "渡船已离岸" and the replay button were visible. The 16-second slot was observation only. |

Both recordings started from navigation in fresh Chrome for Testing 157.0.8103.6 processes on Windows, with software WebGL2, 960 × 540, Chinese locale and fresh storage. The protocol used screen-visible cues only. Both videos were decoded to 400 frames, 20 fps, 20.000 seconds. Neither game produced a page exception or failed asset request during recording. The 4-second first action and later action slots were imposed by the protocol. The operator checked one route per draft, without replaying either win or timing first-time human understanding.

| Blind label | Video | SHA-256 | Captured compositor frames |
| --- | --- | --- | ---: |
| cobalt | cobalt/recorded/opening-20s.mp4 | a1f29fee20af1843368fca703dd237794323d204265d31e2d492db149456f29f | 1,931 |
| juniper | juniper/recorded/opening-20s.mp4 | 9d865acac11dc7ebf200080e2bfbd151c379eedc1e601fe9f78fca617e7adda6 | 1,813 |

Opening, input and evidence readback live with each label. The game, engine and HTML hashes were checked both before and after each browser session. Scores were fixed under these labels before inspecting the treatment mapping.


const W = 960, H = 540, LIMIT = 45;
const DARK = 0x091722, INK = 0x11232e, WHITE = 0xf3eee0, MIST = 0xa1b8be;
const GOLD = 0xffca76, GREEN = 0x91dfbc, RED = 0xff917a;
const floors = [[28,337,369,426],[352,369,531,398],[515,352,868,394]];
const goals = [
  { x:280, y:374, lift:74, name:'取货', action:'搬起木箱', hint:'去码头灯下搬起第一箱货。' },
  { x:628, y:380, lift:63, name:'装船', action:'固定货箱', hint:'走过跳板，把木箱放进甲板上的黄框。' },
  { x:525, y:380, lift:58, name:'解缆', action:'解开缆绳', hint:'回到船尾，解开系在岸上的缆绳。' },
  { x:796, y:370, lift:103, name:'离港', action:'启动渡船', hint:'到驾驶台启动引擎，驶离渡口。' }
];
let s;
const clamp = (v,lo,hi) => Math.max(lo,Math.min(hi,v));
const lerp = (a,b,t) => a+(b-a)*t;
const put = (sprite,x,y) => { sprite.x=x; sprite.y=y; return sprite; };
const onFloor = (x,y,r) => x>=r[0] && y>=r[1] && x<=r[2] && y<=r[3];
const walkable = (x,y) => floors.some(r=>onFloor(x,y,r));
const zone = (x,y) => onFloor(x,y,floors[0]) ? 0 : onFloor(x,y,floors[2]) ? 2 : 1;

function box(g,x,y,w,h,c,a=1) {
  g.lineStyle().beginFill(c,a).drawRect(x,y,w,h).endFill();
}
function round(g,x,y,w,h,r,c,a=1) {
  g.lineStyle().beginFill(c,a).drawRoundRect(x,y,w,h,r).endFill();
}
function oval(g,x,y,w,h,c,a=1) {
  g.lineStyle().beginFill(c,a).drawEllipse(x,y,w,h).endFill();
}
function dot(g,x,y,r,c,a=1) {
  g.lineStyle().beginFill(c,a).drawCircle(x,y,r).endFill();
}
function poly(g,c,points,a=1) {
  g.lineStyle().beginFill(c,a).moveTo(points[0],points[1]);
  for(let i=2;i<points.length;i+=2) g.lineTo(points[i],points[i+1]);
  g.lineTo(points[0],points[1]).endFill();
}
function line(g,w,c,a,...p) {
  g.lineStyle(w,c,a).moveTo(p[0],p[1]);
  for(let i=2;i<p.length;i+=2) g.lineTo(p[i],p[i+1]);
  g.lineStyle();
}
function gradient(g,x,y,w,h,stops) {
  g.lineStyle().beginLinearGradientFill(x,y,x,y+h,stops.map(([offset,color])=>({offset,color})))
    .drawRect(x,y,w,h).endFill();
}
function halo(g,x,y,r,color,alpha) {
  g.lineStyle().beginRadialGradientFill(x,y,r,[{offset:0,color,alpha},{offset:1,color,alpha:0}])
    .drawCircle(x,y,r).endFill();
}
function label(game,words,x,y,size,color=WHITE,align='left',bold=false,layer=game.ui) {
  return game.text(words,{x,y,size,color,align,bold,layer});
}
function random(seed) {
  return () => {
    seed=(1664525*seed+1013904223)>>>0;
    return seed/4294967296;
  };
}

function landscape(game) {
  const rnd=random(481);
  game.sprite(g=>{
    gradient(g,0,104,W,173,[[0,0x172330],[.48,0x2e4b58],[1,0x799091]]);
    halo(g,666,216,182,0x9eaca4,.3);
    poly(g,0x1d2c3a,[0,104,960,104,960,143,828,130,705,156,592,147,468,169,330,153,228,162,106,139,0,152]);
    poly(g,0x263c49,[0,159,106,147,233,170,336,162,423,179,584,164,666,174,528,187,440,190,336,182,250,193,121,175,0,178]);
    const ridge=[0,217];
    for(let x=22;x<960;x+=24) ridge.push(x,206+Math.sin(x*.016)*13+Math.sin(x*.033)*8+rnd()*9);
    ridge.push(960,213,960,264,0,264);
    poly(g,0x47616a,ridge);
    poly(g,0x334f59,[0,233,103,221,213,205,249,212,292,231,381,239,531,251,0,263]);
    poly(g,0x3a555c,[566,254,655,242,704,239,769,221,831,230,879,212,960,210,960,266,566,266]);
    for(let i=0;i<38;i++) {
      const x=666+rnd()*294, y=247-Math.max(0,x-688)*.076+rnd()*7;
      if(i%3===0) poly(g,0x314a53,[x-4,y,x,y-8,x+4,y,x+3,y+4,x-3,y+4]);
      else box(g,x,y,2+rnd()*5,1,0xb8ac85,.32);
    }
    box(g,886,212,5,24,0x2e454e);
    box(g,884,209,9,4,0x233a45);
    dot(g,889,211,1.7,GOLD,.9);
    gradient(g,0,253,W,218,[[0,0x3d6269],[.46,0x244650],[1,0x142e3b]]);
    for(let i=0;i<100;i++) {
      const x=rnd()*W, y=254+rnd()*213;
      box(g,x,y,6+rnd()*56,.6+rnd(),i%2?0xb5cdca:0x091e2c,.1+rnd()*.21);
    }
    for(let i=0;i<31;i++) {
      const y=259+rnd()*180, x=701+(rnd()-.5)*(26+(y-259)*1.1);
      box(g,x,y,5+rnd()*37,1+rnd(),0xa2b7a5,.08+rnd()*.14);
    }
  });
  return Array.from({length:26},()=>{
    const x=rnd()*W, y=261+rnd()*199, w=10+rnd()*41;
    const sprite=game.sprite(g=>line(g,1,0x97c5c5,1,0,0,w*.75,0,w,-1));
    return {sprite,x,y,w,rate:9+rnd()*18,phase:rnd()*7};
  });
}

function dock(game) {
  const rnd=random(72);
  game.sprite(g=>{
    poly(g,0x142633,[-33,331,353,326,406,400,383,439,-29,453]);
    for(const [x,y] of [[37,422],[116,419],[201,411],[291,407],[367,406]]) {
      oval(g,x-23,y+23,44,7,0x0c2530,.6);
      poly(g,0x182733,[x-7,y,x+9,y,x+6,y+31,x-4,y+33]);
      box(g,x-5,y,3,29,0x3a4244,.8);
    }
    poly(g,0x564e48,[-28,331,353,325,404,401,382,425,-25,438]);
    poly(g,0x312e33,[-25,421,387,407,382,427,-25,443]);
    line(g,2,0x867262,.8,0,420,386,406,400,397);
    for(let i=0;i<12;i++) {
      const y=334+i*7.35, end=360+(y-334)*.47;
      line(g,1.6,0x302e33,.77,0,y,end,y-5);
      line(g,.75,0x938172,.32,0,y+2,end-4,y-3);
      for(let j=0;j<3;j++) {
        const x=rnd()*338;
        line(g,1,0x201f26,.37,x,y+4,x+7+rnd()*32,y+3.5);
      }
    }
    for(const [x,y,w] of [[56,392,94],[195,410,88],[253,352,88],[306,395,67]]) {
      oval(g,x-w/2,y-3,w,8,0x2a3e47,.8);
      line(g,1,0x94a19b,.5,x-w*.36,y+3,x+w*.3,y+3);
    }
    for(const x of [23,102,181,261,345]) {
      const y=420-(x/345)*10;
      box(g,x-3,y-15,7,33,0x252a32);
      box(g,x-3,y-15,7,3,0x8a7963);
      box(g,x-2,y-7,2,17,0x65584f);
    }
    poly(g,0x1a2a35,[-10,245,62,211,187,231,221,254,221,321,183,341,-10,352]);
    poly(g,0x283a44,[0,255,184,245,184,333,0,347]);
    poly(g,0x1b2c36,[184,245,221,252,221,321,184,333]);
    poly(g,0x344651,[-18,250,54,214,109,215,224,244,185,262,0,270]);
    line(g,2,0x667275,.65,0,250,59,220,109,220,209,245);
    line(g,3,0x142733,.9,0,269,185,260,222,246);
    for(let x=12;x<183;x+=16) line(g,1,0x121f28,.66,x,270-x*.043,x,344-x*.061);
    box(g,51,272,68,67,0x172731);
    box(g,55,276,60,57,0x3c4948);
    for(let y=281;y<333;y+=5) {
      box(g,56,y,58,1,0x1e2c36);
      box(g,56,y+1,58,1,0x617068,.38);
    }
    box(g,132,273,38,24,0x14252f);
    box(g,135,276,32,17,0x5c716b);
    box(g,150,275,2,20,0x25363d);
    box(g,134,284,34,2,0x25363d);
    line(g,2,0x182b35,1,199,247,199,216,209,208,239,208);
    dot(g,239,210,3,0x5b716b);
    for(const [x,y,w] of [[12,348,28],[38,345,28],[29,360,30],[9,362,22]]) {
      box(g,x-w/2,y-17,w,17,0x3d4241);
      line(g,1,0x6f7060,1,x-w/2,y-17,x+w/2,y-17,x+w/2,y);
      line(g,1,0x282d32,1,x-w/2,y-5,x+w/2,y-14);
    }
    poly(g,0xffcb77,[265,301,277,303,313,368,267,390,229,383],.1);
    halo(g,271,305,61,GOLD,.26);
    oval(g,230,372,91,15,GOLD,.15);
    line(g,4,0x1d2a32,1,236,386,236,292,245,282,266,284,271,296);
    line(g,1,0x77807a,.82,237,378,237,292,245,283,263,285);
    box(g,230,382,12,5,0x242930);
    poly(g,0x31363b,[262,296,278,296,282,304,259,304]);
    box(g,262,304,16,3,0xffde9a);
    dot(g,270,306,2,0xffedb6);
    line(g,1.2,0xf1c782,.48,250,378,276,377,292,378);
    round(g,350,365,16,9,3,0x1c292f);
    box(g,352,366,12,2,0x91a098);
  });
  label(game,'渡口库房',86,245,12,0x9aa796,'center',true,'world');
}

function makeFerry(game) {
  const boat=put(game.sprite(g=>{
    oval(g,-16,54,443,45,0x0a2631,.6);
    poly(g,0x112b38,[-8,28,417,19,418,35,396,64,361,82,16,82,-8,61]);
    poly(g,0x315760,[-8,29,416,19,413,36,391,61,363,72,8,72,-8,57]);
    poly(g,0x8b5149,[-8,54,393,54,383,65,362,75,11,75,-8,61]);
    line(g,2,0xb59473,.86,0,48,379,48,408,32);
    poly(g,0x82918a,[-8,27,18,1,325,1,419,23,382,52,-7,52]);
    poly(g,0x556f72,[6,28,30,7,320,7,402,23,376,47,6,47]);
    line(g,2,0xb4ba9c,1,9,28,32,7,322,7,406,24,376,47,0,47);
    for(let x=26;x<390;x+=15) line(g,.8,0x263e46,.44,x,11,x-14,46);
    poly(g,0x435c61,[61,21,198,21,189,47,60,47]);
    line(g,2,0xe7bb76,.92,105,34,109,27,166,27,173,34);
    line(g,2,0xe7bb76,.92,105,42,104,47,173,47,175,41);
    for(const x of [32,61,124,184,237,292,340]) {
      line(g,2,0x203d47,1,x,45,x,34);
      box(g,x-1,33,2,9,0xb8baa4);
    }
    line(g,1.7,0xb7b9a4,.86,60,34,100,34);
    line(g,1.7,0xb7b9a4,.86,180,34,369,34,401,21);
    box(g,265,-49,94,63,0x354f57);
    poly(g,0x759093,[247,-48,329,-50,329,10,245,10]);
    poly(g,0x48636a,[329,-50,362,-32,363,11,329,10]);
    poly(g,0x9aa99a,[241,-49,253,-61,327,-62,369,-37,361,-33,323,-51,242,-40]);
    line(g,2,0xc3c7aa,.86,241,-49,323,-54,365,-37);
    box(g,253,-38,69,29,0x243f48);
    for(let x=257;x<312;x+=22) {
      box(g,x,-34,18,21,0xe2ad70);
      poly(g,0xfbd894,[x,-34,x+10,-34,x+2,-13,x,-13],.7);
      box(g,x,-15,18,2,0xac764f);
    }
    poly(g,0x263e46,[335,-42,355,-31,356,-11,335,-17]);
    poly(g,0xdba574,[338,-37,352,-29,352,-15,338,-20]);
    box(g,250,-2,77,3,0xa1a99a);
    box(g,315,-84,4,23,0x223642);
    line(g,2,0x9fa99b,1,316,-83,309,-96);
    line(g,1.4,0x8d9b92,1,305,-87,329,-87);
    dot(g,309,-97,2,0xcb795c);
    round(g,224,-27,13,24,3,0x233944);
    box(g,222,-28,17,4,0x707f7a);
    for(const x of [20,218,357]) {
      oval(g,x-7,43,14,25,0x172832);
      oval(g,x-4,48,8,15,0x4d5959);
      oval(g,x-2,51,4,10,0x273740);
    }
    box(g,27,29,17,8,0x293e45);
    round(g,27,27,17,5,2,0x9da58c);
    poly(g,0x213945,[326,33,331,12,345,10,351,16,346,34]);
    line(g,2,0x92a696,1,328,16,341,12,349,15);
    dot(g,338,11,7.5,0x17313e);
    dot(g,338,11,5,0x9bb3a6);
    dot(g,338,11,3.5,0x1c3340);
    line(g,1,0xb3bca6,1,333,11,343,11);
    box(g,378,21,4,14,0x243b47);
    dot(g,380,20,3.4,0x8dceab);
  }),490,338);
  label(game,'渡口号',265,52,13,0xf0d9ad,'center',true,boat);
  label(game,'01',63,51,14,0xf0d9ad,'center',true,boat);
  return boat;
}

function makeRamp(game) {
  return put(game.sprite(g=>{
    poly(g,0x102c38,[0,-6,154,-3,165,31,-6,34],.65);
    poly(g,0x413935,[-6,-12,155,-8,160,24,-6,30]);
    poly(g,0x856b52,[-5,-11,155,-8,156,19,-5,25]);
    for(let x=1;x<155;x+=10) line(g,1.6,0x473c36,1,x,-9,x,22-x*.028);
    line(g,2,0xb49b6b,.95,-5,-11,155,-8);
    line(g,2,0xb49b6b,.95,-5,24,156,19);
    for(const x of [9,37,66,95,123,150]) {
      box(g,x,-5,4,2,0x3a3430);
      box(g,x,14,4,2,0x3a3430);
    }
  }),365,378);
}
function makeCrate(game,layer) {
  return game.sprite(g=>{
    oval(g,-24,-5,48,12,0x13232c,.55);
    poly(g,0xf5ba66,[-22,-30,-12,-39,19,-39,25,-30]);
    poly(g,0x9b5937,[17,-30,25,-31,25,-9,16,-1]);
    box(g,-22,-30,40,29,0xc48446);
    line(g,2,0x744a33,1,-21,-23,17,-23);
    line(g,2,0x744a33,1,-21,-8,17,-8);
    for(const x of [-19,11]) box(g,x,-29,4,27,0xf0b663);
    line(g,2,0xe0a15a,1,-17,-4,13,-28);
    box(g,-9,-24,15,15,0x3c4647);
    line(g,1.5,0xffdc8f,1,-5,-19,-1,-22,3,-19);
    line(g,1.5,0xffdc8f,1,-1,-22,-1,-13);
  },layer);
}
function makeWorker(game) {
  const body=game.sprite(g=>oval(g,-17,-5,34,11,0x112832,.58));
  const leg=()=>game.sprite(g=>{
    round(g,-4,-11,7,13,3,0x33444a);
    round(g,-5,-3,11,5,2,0x172632);
    box(g,-4,0,9,1,0x566461);
  },body);
  const legs=[leg(),leg()];
  const coat=game.sprite(g=>{
    poly(g,0x896043,[-11,-37,6,-37,14,-14,9,-9,-14,-12]);
    poly(g,0xe5a449,[-9,-38,6,-38,9,-23,13,-14,-12,-14,-11,-30]);
    poly(g,0xffcd70,[-10,-37,-1,-37,1,-22,-12,-17]);
    line(g,1,0x965d38,1,3,-34,3,-14);
    line(g,2.5,0xeee0af,1,-10,-19,10,-19);
    round(g,-11,-53,23,20,9,0xe9ac50);
    poly(g,0xffd879,[-13,-43,-9,-51,0,-54,9,-49,14,-43,8,-40,-11,-40]);
    poly(g,0x634d3b,[2,-47,10,-45,11,-38,5,-33,0,-38]);
    poly(g,0xe7b78c,[4,-45,9,-43,10,-39,6,-35,2,-39]);
    dot(g,7,-41,1,0x25363d);
    poly(g,0xe0a24e,[-11,-34,-5,-35,-2,-27,5,-24,2,-19,-8,-23]);
    oval(g,1,-25,7,6,0xe7b78c);
    line(g,1.2,0xffd475,1,-10,-33,-7,-26,-1,-23);
  },body);
  return {body,legs,coat};
}

function buildHUD(game) {
  game.sprite(g=>{
    box(g,0,0,W,112,DARK);
    box(g,0,458,W,82,DARK);
    box(g,0,111,W,1,0x39535c);
    box(g,0,458,W,1,0x39535c);
    box(g,26,25,3,63,GOLD);
    box(g,253,24,1,65,0x314750);
    box(g,760,24,1,65,0x314750);
    round(g,787,83,145,4,2,0x29424d);
  },game.ui);
  label(game,'暴雨渡口',42,22,40,WHITE,'left',true);
  label(game,'末班渡船 · 第一箱货',44,71,14,MIST);
  label(game,'当前任务',278,23,12,GOLD,'left',true);
  s.title=label(game,'',277,43,25,WHITE,'left',true);
  s.hint=label(game,'',278,77,15,MIST);
  s.clockTitle=label(game,'距暴雨抵达',787,23,12,MIST,'left',true);
  s.clock=label(game,'00:45',785,39,33,WHITE,'left',true);
  s.fuse=put(game.sprite(g=>round(g,0,0,145,4,2,GOLD),game.ui),787,83);
  s.warnFuse=put(game.sprite(g=>round(g,0,0,145,4,2,RED),game.ui),787,83);
  s.warnFuse.visible=false;
  s.steps=goals.map((goal,i)=>{
    const x=38+146*i;
    const badge=put(game.sprite(g=>dot(g,0,0,11,0x263d49),game.ui),x,484);
    const num=label(game,String(i+1),x,476,12,WHITE,'center',true);
    const text=label(game,goal.name,x+18,473,17,WHITE,'left',true);
    if(i<3) game.sprite(g=>line(g,1,0x34505b,1,x+68,484,x+120,484),game.ui);
    return {badge,num,text};
  });
  s.help=label(game,'方向键 / WASD 移动 · E / 空格互动 · 点击场景也可移动',27,512,13,MIST);
  s.button=game.sprite(g=>{
    round(g,727,473,206,51,9,0xc48e59);
    round(g,727,470,206,50,9,GOLD);
    round(g,740,482,27,26,5,0x513b31);
    line(g,2,0x624b3a,1,904,491,909,496,904,501);
  },game.ui);
  label(game,'E',753,486,15,WHITE,'center',true);
  s.action=label(game,'',833,483,19,0x2a262a,'center',true);
  game.onTap(s.button,()=>act(game,true));
}

function mark(game) {
  s.marker=game.sprite(g=>{},game.world);
  s.pin=game.sprite(g=>{
    round(g,-54,-16,108,29,6,0x142a35,.96);
    line(g,1,0xe8b66c,1,-48,-16,48,-16);
    poly(g,GOLD,[-6,12,6,12,0,18]);
  },s.marker);
  s.pinText=label(game,'',0,-12,16,GOLD,'center',true,s.pin);
}
function syncMission() {
  const goal=goals[s.step];
  s.marker.visible=!!goal;
  if(goal) {
    put(s.marker,goal.x,goal.y);
    s.marker.graphics.clear();
    oval(s.marker.graphics,-25,-7,50,14,GOLD,.18);
    line(s.marker.graphics,1.5,GOLD,.95,-24,1,-24,6,-14,8);
    line(s.marker.graphics,1.5,GOLD,.95,24,1,24,6,14,8);
    s.pinText.text=goal.action;
    s.title.text=goal.action;
    s.hint.text=goal.hint;
    s.action.text=goal.action;
  } else {
    s.title.text='驶离码头';
    s.hint.text='第一箱货已固定，渡船正在离岸。';
    s.action.text='正在离港';
    s.button.alpha=.62;
    s.clockTitle.text='已离岸 · 剩余时间';
  }
  s.steps.forEach(({badge,num,text},i)=>{
    const color=i<s.step?GREEN:i===s.step?GOLD:0x28404d;
    badge.graphics.clear();
    dot(badge.graphics,0,0,11,color);
    num.color=i<=s.step?DARK:MIST;
    num.text=i<s.step?'✓':String(i+1);
    text.color=i<s.step?GREEN:i===s.step?GOLD:MIST;
  });
}

function setup(game) {
  s={x:162,y:398,step:0,elapsed:0,age:0,started:false,departure:0,offset:0,dy:0,
    end:null,route:[],queued:false,facing:1,pace:0,note:0,lastSecond:LIMIT,stormBeat:0};
  s.ripples=landscape(game);
  s.wake=game.sprite(()=>{});
  dock(game);
  s.boat=makeFerry(game);
  s.ramp=makeRamp(game);
  s.rope=game.sprite(g=>{
    g.lineStyle(4,0x273037,1).moveTo(356,369).curveTo(478,390,518,367).lineStyle();
    g.lineStyle(1.5,0xc1a680,.94).moveTo(356,368).curveTo(478,387,518,366).lineStyle();
  });
  s.deckCrate=put(makeCrate(game,s.boat),138,41);
  s.deckCrate.visible=false;
  mark(game);
  s.crate=put(makeCrate(game),280,374);
  s.worker=makeWorker(game);
  put(s.worker.body,s.x,s.y);
  put(s.worker.legs[0],-6,-1);
  put(s.worker.legs[1],5,-1);
  s.held=put(makeCrate(game,s.worker.body),15,-6);
  s.held.scaleX=.66;
  s.held.scaleY=.66;
  s.held.visible=false;
  s.rain=game.sprite(()=>{});
  const rnd=random(7219);
  s.drops=Array.from({length:94},()=>[rnd()*1000,rnd()*348,110+rnd()*190,4+rnd()*6]);
  s.tint=game.sprite(g=>box(g,0,112,W,346,0xc8ecf6));
  s.tint.alpha=0;
  buildHUD(game);
  syncMission();
  s.help.text='移动或点击场景开始计时 · 近处按 E / 空格，或点击右侧按钮';
  game.sfx.define('wood',[{wave:'triangle',from:116,to:55,seconds:.13,volume:.55},{wave:'noise',from:140,seconds:.1,volume:.19}]);
  game.sfx.define('lash',[{wave:'noise',from:380,seconds:.12,volume:.22},{wave:'sine',from:470,to:240,seconds:.15,volume:.22}]);
  game.sfx.define('horn',[{wave:'triangle',from:147,to:142,seconds:.7,volume:.32},{wave:'sine',from:74,to:71,seconds:.75,volume:.34}]);
}

function begin() {
  if(!s.started) {
    s.started=true;
    s.help.text='方向键 / WASD 移动 · E / 空格互动 · 点击场景也可移动';
  }
}
function plan(tx,ty,queued=false) {
  const a=zone(s.x,s.y), b=zone(tx,ty), path=[];
  if(a!==b) {
    if(a===0||b===0) path.push([359,383]);
    if(a===2||b===2) path.push([524,383]);
    if(a>b) path.reverse();
  }
  path.push([tx,ty]);
  s.route=path;
  s.queued=queued;
  begin();
}
function nearestFloor(x,y) {
  let best=Infinity, point=[s.x,s.y];
  for(const [l,t,r,b] of floors) {
    const u=clamp(x,l,r), v=clamp(y,t,b), d=(u-x)**2+(v-y)**2;
    if(d<best) { best=d; point=[u,v]; }
  }
  return point;
}
function flashNote(message) {
  s.help.text=message;
  s.note=2.2;
}
function act(game,approach) {
  if(s.end||s.step>=goals.length) return;
  const goal=goals[s.step];
  if(Math.hypot(goal.x-s.x,goal.y-s.y)>29 || zone(s.x,s.y)!==zone(goal.x,goal.y)) {
    if(approach) plan(goal.x,goal.y,true);
    else flashNote('再靠近一些，走到金色标记旁。');
    return;
  }
  begin();
  s.route=[];
  s.queued=false;
  s.step++;
  if(s.step===1) {
    s.crate.visible=false;
    s.held.visible=true;
    game.sfx.play('wood');
  } else if(s.step===2) {
    s.held.visible=false;
    s.deckCrate.visible=true;
    game.sfx.play('wood',{pitch:.85});
    game.sfx.play('coin',{volume:.28,pitch:.8});
    game.burst(628,376,{color:GOLD,count:8,speed:34,life:.33,size:2,gravity:48});
  } else if(s.step===3) {
    s.rope.visible=false;
    game.sfx.play('lash');
  } else {
    game.sfx.play('horn');
  }
  syncMission();
}
function move(dt,game) {
  const keys=game.keys, pointer=game.pointer, axis=keys.axis();
  const goal=goals[s.step];
  const tap=pointer.pressed && pointer.y>=113 && pointer.y<458;
  if(tap) {
    const onMarker=Math.abs(pointer.x-goal.x)<53 && Math.abs(pointer.y-(goal.y-goal.lift))<21;
    const onTarget=Math.abs(pointer.x-goal.x)<34 && pointer.y>=goal.y-47 && pointer.y<=goal.y+16;
    if(onMarker||onTarget) act(game,true);
    else if(pointer.y>=329) plan(...nearestFloor(pointer.x,pointer.y));
    if(s.step>=goals.length) return false;
  }
  let dx=axis.x, dy=axis.y, mag=Math.hypot(dx,dy);
  const speed=s.step===1?126:174;
  const oldX=s.x, oldY=s.y;
  if(mag>.14) {
    begin();
    s.route=[];
    s.queued=false;
    const scale=speed*dt/Math.max(1,mag);
    if(walkable(s.x+dx*scale,s.y)) s.x+=dx*scale;
    if(walkable(s.x,s.y+dy*scale)) s.y+=dy*scale;
  } else if(s.route.length) {
    const [x,y]=s.route[0];
    dx=x-s.x; dy=y-s.y; mag=Math.hypot(dx,dy);
    if(mag<=speed*dt+.01) {
      s.x=x; s.y=y; s.route.shift();
      if(!s.route.length&&s.queued) act(game,false);
    } else {
      s.x+=dx/mag*speed*dt;
      s.y+=dy/mag*speed*dt;
    }
  }
  if(s.step<goals.length && (keys.pressed('e')||keys.pressed('space')||keys.pressed('enter')||keys.pressed('pad:a'))) act(game,false);
  if(Math.abs(s.x-oldX)>.04) s.facing=s.x>oldX?1:-1;
  return Math.hypot(s.x-oldX,s.y-oldY)>.04;
}

function weather(game,dt) {
  const t=s.age, level=clamp(s.elapsed/LIMIT,0,1);
  const heavy=s.end==='lost'?1:level;
  for(const w of s.ripples) {
    const x=(w.x+t*w.rate)%(W+w.w)-w.w;
    put(w.sprite,x,w.y+Math.sin(t*1.8+w.phase)*1.2);
    w.sprite.alpha=.12+.22*(.5+.5*Math.sin(w.phase+t*2));
  }
  const g=s.rain.graphics.clear();
  const count=game.reducedMotion?34:Math.floor(51+43*heavy);
  for(let pass=0;pass<2;pass++) {
    g.lineStyle(pass?1.35:.78,pass?0xbcdddf:0x94b5c2,pass?.29:.24);
    for(let i=pass;i<count;i+=2) {
      const [ox,oy,v,size]=s.drops[i], drift=1+heavy*.5;
      const x=((ox-t*v*.46*drift)%1000+1000)%1000-20;
      const y=112+(oy+t*v*drift)%346;
      if(y<118||y>451) continue;
      g.moveTo(x,y).lineTo(x-size*(.45+heavy*.33),Math.min(458,y+size));
    }
  }
  g.lineStyle();
  if(s.started&&s.step<4&&!s.end) {
    const beat=s.elapsed>=34?2:s.elapsed>=16?1:0;
    if(beat>s.stormBeat) {
      s.stormBeat=beat;
      s.tint.alpha=game.reducedMotion?.05:.17;
      game.sfx.play('wind',{volume:.28,pitch:.67});
    }
  }
  s.tint.alpha=Math.max(0,s.tint.alpha-dt*.55);
}
function departure(dt,game) {
  s.departure+=dt;
  const p=clamp(s.departure/2.7,0,1);
  s.offset=402*p*p;
  s.dy=-35*p;
  s.ramp.visible=p<.24;
  s.ramp.scaleY=1-.7*clamp(p/.24,0,1);
  const g=s.wake.graphics.clear();
  for(let i=0;i<7;i++) {
    const x=480+s.offset-i*(12+p*18), y=403+s.dy+i*3;
    g.lineStyle(2-i*.16,0xb7dfd6,(.24+i*.012)*Math.min(1,p*6))
      .moveTo(x-38-i*4,y+9).curveTo(x-12,y+11-i*3,x+24,y-2).lineStyle();
  }
  if(p===1) finish(game,'won');
}
function finish(game,outcome) {
  s.end=outcome;
  s.marker.visible=false;
  s.endAge=0;
  const won=outcome==='won', accent=won?GREEN:RED;
  const layer=game.sprite(g=>{
    box(g,0,112,W,346,0x081821,.7);
    round(g,239,150,482,273,13,0x07141d,.75);
    round(g,245,145,470,270,12,0x41585d);
    round(g,247,147,466,266,11,0x122632);
    dot(g,480,182,16,accent);
    if(won) line(g,3,0x163639,1,472,182,478,188,488,176);
    else {
      line(g,3,0x452a2c,1,480,174,480,183);
      dot(g,480,189,1.8,0x452a2c);
    }
    line(g,1,0x3f5960,1,285,320,675,320);
  },game.ui);
  label(game,won?'渡船已离港':'暴雨封航',480,207,38,WHITE,'center',true,layer);
  label(game,won?'第一箱货已随船出发。':'风雨盖住了航道，渡船只能留在港内。',480,260,16,MIST,'center',false,layer);
  const detail=won?'赶在暴雨前 '+Math.ceil(LIMIT-s.elapsed)+' 秒离开码头':'完成进度 '+s.step+' / '+goals.length;
  label(game,detail,480,288,15,accent,'center',true,layer);
  const again=game.sprite(g=>round(g,389,340,182,43,8,accent),layer);
  label(game,'再跑一趟',480,350,18,DARK,'center',true,layer);
  label(game,'回车 / R 重新开始',480,391,12,MIST,'center',false,layer);
  game.onTap(again,()=>game.restart());
  game.sfx.play(won?'win':'lose',{volume:.46});
}
function update(dt,game) {
  dt=Math.min(dt,.05);
  s.age+=dt;
  if(game.keys.pressed('r')) { game.restart(); return; }
  let walking=false;
  if(s.end) {
    s.endAge+=dt;
    if(s.endAge>.22&&(game.keys.pressed('enter')||game.keys.pressed('space')||game.keys.pressed('pad:a'))) {
      game.restart(); return;
    }
  } else if(s.step===4) departure(dt,game);
  else {
    walking=move(dt,game);
    if(s.started&&s.step<4) {
      s.elapsed=Math.min(LIMIT,s.elapsed+dt);
      const left=Math.ceil(LIMIT-s.elapsed);
      if(left!==s.lastSecond) {
        s.lastSecond=left;
        s.clock.text='00:'+String(left).padStart(2,'0');
        s.clock.color=left<=10?RED:WHITE;
        if(left<=5&&left>0) game.sfx.play('pop',{volume:.18,pitch:1.15});
      }
      s.fuse.scaleX=s.warnFuse.scaleX=Math.max(.001,1-s.elapsed/LIMIT);
      s.warnFuse.visible=left<=10;
      if(left===0) finish(game,'lost');
    }
  }
  if(s.note>0) {
    s.note-=dt;
    if(s.note<=0) s.help.text='方向键 / WASD 移动 · E / 空格互动 · 点击场景也可移动';
  }
  const goal=goals[s.step];
  if(goal) s.pin.y=-goal.lift+(game.reducedMotion?0:Math.sin(s.age*4.5)*3);
  s.pace+=walking?dt*(s.step===1?13:18):0;
  const stride=walking?Math.sin(s.pace)*4.5:0;
  const bob=walking?Math.abs(Math.sin(s.pace))*1.8:0;
  const waterBob=s.step===4?Math.sin(s.age*4)*1.1:0;
  put(s.boat,490+s.offset,338+s.dy+waterBob);
  put(s.worker.body,s.x+s.offset,s.y+s.dy+waterBob);
  s.worker.body.scaleX=s.facing;
  put(s.worker.legs[0],-6+stride,-1);
  put(s.worker.legs[1],5-stride,-1);
  s.worker.coat.y=-bob;
  s.held.y=-6-bob;
  weather(game,dt);
}

await Egret.play({width:W,height:H,background:DARK,setup,update});

# Rainstorm Ferry opening observation

Frozen before viewing either draft.

Two unedited, separately generated games use blind labels cobalt and juniper. The person or agent operating the browser receives only the playable files and their checksums. The author retains the label-to-entry mapping until both observations are written. The driver never reads the game files or generation receipts for controls or clues.

Run each entry in a fresh Windows Chrome for Testing 157.0.8103.6 process with a 960 × 540 viewport, DPR 1, zh-CN locale, software WebGL2 (SwiftShader), local HTTP, fresh storage and no external connections. Use the previous study's compositor capture script unchanged. A recording runs uncut from navigation for 20.000 seconds and is encoded silently at 20 fps. Verify each MP4 by decoding 400 frames and checking its SHA-256. Report browser exceptions and failed requests as observed.

At 4, 8, 12 and 16 seconds the driver may perform one action based on visible cues. Activate a blocking start prompt if present. Once in play, prefer the apparent action that moves the first box onto the ferry, then the action that sends that ferry away. If a box needs to be approached first, use the displayed movement control or the visibly identifiable target. Prefer an explicit instruction to a guessed input. Keyboard holds are 1.5 seconds, and a click or key press is discrete. Wait when the next action cannot be inferred from what is shown. Stop giving inputs after visible departure. Do not add actions between the fixed slots.

A disposable replay may expose the next cue with the already selected input prefix. Collect source-free screen images only. Retain the plan that determines the scored recording, and accept its observed outcome even if it differs from the disposable replay. No retries to select a better take. An optional separate playable check may use shorter holds or additional visible actions and is reported outside the scored recording.

From decoded video frames confirm the first effective action and its time, approach or selection before loading, actual loading, and actual departure after cargo is on board. Loading requires the box to be visibly on the ferry, or an equivalent durable cargo/objective state. Departure requires the vessel to visibly leave the dock or an explicit departed state together with visible scene motion. Start clicks, temporary overlays, and weather animation alone do not meet these criteria. Retain screenshots near 3, 7, 11, 15 and 19 seconds, and extra decoded frames for relevant actions. These are automated opening observations without first-time human participants.

The author and root track exact brief, input context and bytes, runtime pin, tool exposure, elapsed time, model, source budget, and tool reads. Gameplay is scored independently of those records.


# Rainstorm Ferry | opening evidence for the confirmation pair

| Blind label | First progress | First box reaches the ferry | Ferry leaves after loading |
| --- | --- | --- | --- |
| onyx | Clicked the marked box at 3.999 s. The worker moved to it, then held the first box on screen at 7 s while the pick-up step was checked. | At 8.005 s clicked the marked yellow deck cargo space. At 11 s the box was on the deck, the loading step was checked and the next instruction was to go to the wheel, untie the rope and start the ferry. | Clicked the visibly marked wheel at 12.000 s. By 13.400 s the boat was separated from the dock and moving, with the box visibly still aboard and steering instructions displayed. At 15 s the boat was farther from the dock, with buoy 2/3 indicated. At 19 s the boat was underway and the next instruction asked for a downward turn. The 16-second slot was left idle as prescribed for completed departure. |
| amber | No playable draft was supplied at the authoring limit. | No browser test. | No browser test. |

The onyx recording started from navigation in a fresh Chrome for Testing 157.0.8103.6 process on Windows, with software WebGL2, 960 × 540, Chinese locale and fresh storage. It decoded to 400 frames, 20 fps and 20.000 seconds, from 1,940 compositor frames. No page exceptions or failed asset requests appeared in the scored window. The operator used three scene clicks and did not steer after departure. The displayed buoy route was not completed.

Video: onyx/recorded/opening-20s.mp4. SHA-256: 7b7caacb00ecec23593b01e730bc43d4496a921d2ac55309f3de667c8cc06ebf. Exact inputs and selected decoded frames are recorded beside the video. The game, engine and HTML hashes were consistent before and after each browser session. This score was frozen before examining the treatment mapping.


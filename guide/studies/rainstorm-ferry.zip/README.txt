Rainstorm Ferry / 暴雨渡口

The old-entry/ and new-entry/ folders hold the two attempts with working reference tools. The old entry produced an unedited game. The new entry timed out, so its evidence consists of the prompt, reads, intermediate byte counts and the empty final response. The pilot/ folder preserves both earlier drafts affected by approvals. To play a completed draft, serve its game/ directory over local HTTP, for example with python -m http.server from that directory. Each capture/first-20s.mp4 begins at navigation and lasts 20 seconds. Input records and selected decoded stills accompany the videos.

generation/ records the exact finished source as returned, the prompt, snapshot hashes and the reference reads that actually returned content. Both games include the same Egret bundle and notices. The independent source-size check uses the complete game file. checksums.json records SHA-256 for all other members.

old-entry/ 和 new-entry/ 保存资料读取工具可用时的两次尝试。旧入口有未经修改的游戏。新入口超时，保留原始提示、阅读记录、中途字节计数及空的最终回答。pilot/ 保留此前受工具审批限制的一轮的两份可运行首稿。用本地静态 HTTP 服务打开完成稿的 game/ 即可运行。capture/first-20s.mp4 从打开页面起完整录制 20 秒，附有输入记录和关键帧。可运行目录都包含同一引擎与许可证。

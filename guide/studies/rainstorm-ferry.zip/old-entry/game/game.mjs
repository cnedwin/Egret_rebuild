const W = 960, H = 540, LIMIT = 50;
const INK = 0x101e29, PAPER = 0xf4ecdc, AMBER = 0xffcc78, MINT = 0x8ce4cf;
const MOOR = { x: 630, y: 369 };
const jobs = [
  { x: 337, y: 373, verb: '抱起货箱', tip: '到黄灯下，抱起标有 01 的货箱。' },
  { x: 574, y: 373, verb: '放进货位', tip: '沿跳板上船，把货箱放进黄线框。' },
  { x: 666, y: 359, verb: '解缆开船', tip: '到舵轮旁解缆，启动渡船。' }
];
const gates = [{ x: 882, y: 346 }, { x: 1100, y: 413 }, { x: 1317, y: 321 }];
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
const lerp = (a, b, t) => a + (b - a) * t;
const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
let run;

function poly(g, c, xy, a = 1) {
  g.beginFill(c, a).moveTo(xy[0], xy[1]);
  for (let i = 2; i < xy.length; i += 2) g.lineTo(xy[i], xy[i + 1]);
  g.endFill();
}
function box(g, c, x, y, w, h, a = 1) {
  g.beginFill(c, a).drawRect(x, y, w, h).endFill();
}
function oval(g, c, x, y, w, h, a = 1) {
  g.beginFill(c, a).drawEllipse(x, y, w, h).endFill();
}
function dot(g, c, x, y, r, a = 1) {
  g.beginFill(c, a).drawCircle(x, y, r).endFill();
}
function line(g, c, w, xy, a = 1) {
  g.lineStyle(w, c, a).moveTo(xy[0], xy[1]);
  for (let i = 2; i < xy.length; i += 2) g.lineTo(xy[i], xy[i + 1]);
  g.lineStyle();
}
function sprite(game, x, y, draw, layer) {
  const s = game.sprite(draw, layer);
  s.x = x;
  s.y = y;
  return s;
}
function label(game, words, x, y, size, color = PAPER, align = 'left', bold = false, layer = game.ui) {
  return game.text(words, { x, y, size, color, align, bold, layer });
}
function sign(game, words, x, y, w, layer) {
  sprite(game, x, y, g => {
    g.beginFill(INK, .94).drawRoundRect(-w / 2, -12, w, 24, 6).endFill();
    poly(g, INK, [-5, 10, 5, 10, 0, 16], .94);
  }, layer);
  label(game, words, x, y - 9, 14, AMBER, 'center', true, layer);
}

function scenery(game) {
  sprite(game, 0, 0, g => {
    g.beginLinearGradientFill(0, 10, 0, 266, [
      { offset: 0, color: 0x131d32 }, { offset: .55, color: 0x455a68 },
      { offset: .83, color: 0x868581 }, { offset: 1, color: 0xc1a18a }
    ]).drawRect(0, 0, 1800, 270).endFill();
    oval(g, 0xe9b593, 530, 152, 385, 106, .09);
    oval(g, 0xe5b396, 598, 191, 246, 61, .13);
    poly(g, 0x263645, [0,120,0,73,130,80,206,63,381,75,495,59,642,65,795,45,956,57,1100,36,1280,58,1470,49,1800,80,1800,125,1610,107,1462,121,1300,110,1128,126,950,106,782,123,620,104,449,117,317,101,138,127], .72);
    poly(g, 0x3d4d59, [0,170,0,132,162,139,250,121,393,136,530,123,654,148,781,132,915,145,1096,129,1200,142,1380,128,1540,146,1800,123,1800,161,1580,156,1410,169,1263,154,1124,171,937,158,803,174,613,157,465,166,326,148,192,170], .61);
    for (let i = 0; i < 48; i++) {
      const x = game.random.range(0, 1750), y = game.random.range(104, 218);
      box(g, 0xc5b4a7, x, y, game.random.range(18, 128), game.random.range(.45, 1.6), .10);
    }
    poly(g, 0x65737c, [0,243,0,219,58,209,110,209,162,192,203,198,257,211,312,216,357,206,414,198,466,209,516,215,591,231,652,221,704,222,778,235,842,219,913,212,975,224,1027,217,1092,225,1168,208,1212,206,1272,220,1328,216,1383,223,1448,210,1498,198,1575,213,1660,199,1732,221,1800,211,1800,247]);
    poly(g, 0x344c58, [0,256,0,236,48,224,97,225,143,218,202,231,223,229,265,243,332,241,392,249,506,251,577,253,660,255,775,250,846,243,916,242,985,227,1040,233,1087,239,1135,244,1223,237,1289,249,1351,248,1404,230,1458,237,1517,223,1573,229,1630,216,1740,236,1800,231,1800,261]);
    for (let i = 0; i < 91; i++) {
      const x = game.random.range(12, 1800);
      if (x > 410 && x < 808) continue;
      const y = x < 410 ? 249 - (410 - x) * .044 : 247 - (x > 1420 ? (x - 1420) * .032 : 0);
      const h = game.random.range(4, 13);
      poly(g, 0x40535e, [x - 3, y, x, y - h, x + 3, y]);
    }
    box(g, 0x283941, 1513, 207, 9, 30);
    box(g, 0xb6aaa0, 1515, 209, 6, 27);
    poly(g, 0x29343e, [1509,208,1517,201,1526,208]);
    dot(g, AMBER, 1518, 211, 2.2);
    g.beginLinearGradientFill(0, 246, 0, 550, [
      { offset: 0, color: 0x657e83 }, { offset: .13, color: 0x3c5e68 },
      { offset: .52, color: 0x224a56 }, { offset: 1, color: 0x152c3c }
    ]).drawRect(0, 250, 1800, 298).endFill();
    for (let i = 0; i < 280; i++) {
      const x = game.random.range(0, 1750), y = game.random.range(251, 544);
      const w = game.random.range(7, 35 + (y - 250) * .26);
      const c = i % 7 === 0 && x > 495 && x < 825 ? 0xe3b69a : i % 3 === 0 ? 0x162d37 : 0x95b3ad;
      poly(g, c, [x, y, x + w * .76, y - .6, x + w, y, x + w * .35, y + game.random.range(.5, 2)], .22);
    }
  });
  run.ripples = Array.from({ length: 46 }, (_, i) => {
    const x = game.random.range(0, 1700), y = game.random.range(260, 530);
    const w = game.random.range(7, 43);
    const s = sprite(game, x, y, g => poly(g, i % 5 ? 0xb1d5ce : AMBER, [-w, 0, 0, -1, w, 0, 0, 1]));
    return { s, x, y, phase: game.random.range(0, 7) };
  });
}

function dock(game) {
  sprite(game, 0, 0, g => {
    poly(g, 0x0d2730, [0,401,439,411,522,425,504,467,0,478], .6);
    for (let x = 24; x < 510; x += 72) {
      box(g, 0x1b292b, x, 406, 13, 44 + (x % 3) * 4);
      box(g, 0x4e4741, x + 1, 414, 3, 36);
      oval(g, 0x7baca2, x - 10, 446 + (x % 3) * 4, 34, 4, .22);
    }
    poly(g, 0x413d3c, [0,418,489,418,503,399,503,425,488,442,0,442]);
    line(g, 0x66564a, 2, [0,432,486,432,503,415]);
    poly(g, 0x716555, [0,305,481,305,503,326,503,399,488,419,0,419]);
    for (let i = 0; i < 8; i++) {
      const y = 310 + i * 14;
      const end = y < 326 ? 482 + (y - 306) : y > 395 ? 503 - (y - 395) * .6 : 503;
      box(g, i % 3 === 0 ? 0x97836a : 0x82715e, 0, y, end, 11);
      for (let x = -61 + (i % 3) * 52; x < end - 12; x += 117) {
        if (x < 1) continue;
        box(g, 0x50463e, x, y, 1, 10);
        dot(g, 0x4d473e, x + 4, y + 4, .8);
        dot(g, 0x51473d, x - 4, y + 8, .8);
      }
    }
    for (let i = 0; i < 52; i++) {
      const x = game.random.range(0, 476), y = game.random.range(308, 416);
      box(g, 0xb5a083, x, y, game.random.range(4, 23), .8, .37);
    }
    line(g, 0xbb9270, 2, [0,418,487,418,502,399]);
    for (const x of [20, 117, 218, 320, 426, 482]) {
      box(g, 0x322e2c, x, 294, 8, 24);
      box(g, 0xa08869, x + 1, 294, 2, 18);
      box(g, 0xcab193, x - 1, 291, 10, 4);
    }
    line(g, 0x413e38, 3, [21,300,67,308,119,300,170,308,220,300,270,308,322,300,374,308,428,300,483,300]);
    for (let i = 0; i < 5; i++) poly(g, AMBER, [448+i*8,397,452+i*8,391,456+i*8,391,452+i*8,397], .66);
    oval(g, 0x514a41, 70, 349, 174, 13, .65);
    poly(g, 0x514d4a, [81,269,204,270,223,255,223,326,205,345,81,345]);
    box(g, 0x3e4b50, 82, 270, 120, 75);
    for (let y = 278; y < 344; y += 8) box(g, 0x6a6a60, 83, y, 117, 1, .7);
    poly(g, 0x28363f, [66,273,96,241,225,241,210,273]);
    poly(g, 0x54626a, [70,269,98,244,219,244,205,269]);
    for (let x = 80; x < 204; x += 12) line(g, 0x313d47, 1, [x,269,x+23,244]);
    box(g, 0x202b34, 65, 270, 147, 6);
    box(g, 0x283139, 158, 291, 35, 54);
    box(g, 0x586262, 162, 294, 27, 49);
    dot(g, AMBER, 184, 323, 1.5);
    box(g, 0x252b2d, 94, 291, 46, 32);
    box(g, 0xd89154, 98, 295, 38, 24);
    box(g, 0xffce7c, 100, 297, 35, 13);
    box(g, 0x68534b, 116, 294, 3, 26);
    box(g, 0x725141, 98, 306, 39, 2);
    poly(g, AMBER, [99,322,136,322,163,376,82,376], .09);
    box(g, 0x26343b, 96, 278, 43, 11);
    oval(g, AMBER, 272, 333, 128, 64, .10);
    oval(g, AMBER, 302, 340, 72, 48, .15);
    line(g, 0x302f30, 5, [304,353,304,300,312,291,328,291]);
    line(g, 0xa69883, 1.5, [305,348,305,301,313,292,328,292]);
    poly(g, INK, [322,292,334,292,340,301,317,301]);
    box(g, 0xffd894, 321, 301, 15, 3);
    poly(g, AMBER, [321,304,335,304,372,369,295,369], .075);
    box(g, 0x272e2f, 484, 332, 7, 19);
    box(g, 0xc0b29a, 481, 330, 13, 5);
  });
  label(game, '渡 口', 117, 277, 9, 0xe1c8a7, 'center', true, 'world');
  run.ramp = sprite(game, 486, 368, g => {
    poly(g, 0x182c32, [0,-13,60,-12,60,16,0,16]);
    poly(g, 0x8e8a75, [0,-13,59,-12,59,11,0,11]);
    for (let x = 4; x < 57; x += 7) box(g, 0x4f514b, x, -11, 2, 21);
    box(g, AMBER, 0, -13, 58, 2);
    box(g, 0xc69e68, 0, 10, 58, 2);
  });
  run.rope = sprite(game, 0, 0, g => line(g, 0xedcf99, 2, [489,334,506,340,524,342,542,337]));
}

function ferry(game) {
  run.wake = Array.from({ length: 14 }, (_, i) => {
    const s = sprite(game, 0, 0, g => poly(g, i % 3 ? 0xaad1c7 : 0xe1e8d5, [-12,0,-4,-1,11,0,5,2,-5,2]));
    s.visible = false;
    return s;
  });
  const boat = sprite(game, MOOR.x, MOOR.y, g => {
    oval(g, 0x101f2b, -119, 9, 235, 51, .54);
    poly(g, 0x122b38, [-109,-26,-120,-8,-116,24,-100,41,57,42,86,33,114,9,116,-8,91,-28]);
    poly(g, 0x235260, [-113,8,-108,30,-96,39,55,39,84,30,112,8,112,-1,81,16,55,24,-96,24]);
    poly(g, 0xba5c47, [-109,25,-102,34,-91,37,54,37,83,28,107,10,82,23,54,30,-93,30]);
    poly(g, 0xc9c4ae, [-106,-28,-116,-11,-110,14,-96,26,53,27,82,19,114,-4,93,-25,61,-34,-91,-34]);
    poly(g, 0x607a79, [-102,-23,-110,-10,-104,10,-94,20,51,21,80,13,107,-4,90,-20,59,-28,-91,-28]);
    for (let y = -22; y < 17; y += 6) line(g, 0x486665, 1, [-99,y, y < -14 ? 79 : 66,y]);
    for (const x of [-91, -59, -12, 34, 61]) {
      box(g, 0xf0d6a6, x, 13, 2, 11);
      dot(g, 0xf4e5bf, x + 1, 13, 2.4);
    }
    line(g, 0xe8d0aa, 1.5, [-92,14,-56,16,-10,16,35,16,62,14]);
    for (const x of [-92, -47, 25, 64]) {
      oval(g, 0x203038, x - 4, 24, 10, 10);
      oval(g, 0x5f6662, x - 2, 26, 6, 4);
    }
    box(g, 0x3b6062, -71, -9, 31, 25);
    const corners = [[-71,-9,1,1],[-40,-9,-1,1],[-71,16,1,-1],[-40,16,-1,-1]];
    for (const [x,y,sx,sy] of corners) line(g, AMBER, 2, [x,y+sy*6,x,y,x+sx*7,y]);
    poly(g, 0x273e47, [-23,-54,34,-54,51,-42,51,-15,37,-8,-22,-8]);
    poly(g, 0xc3b9a1, [-21,-49,32,-49,47,-39,47,-16,34,-11,-21,-11]);
    poly(g, 0xe4d8ba, [-21,-49,32,-49,32,-12,-21,-12]);
    box(g, 0x2b4550, -17, -44, 45, 19);
    box(g, 0xd9a46d, -15, -42, 18, 15);
    box(g, 0xf6c58a, 7, -42, 19, 15);
    poly(g, 0xc38e61, [35,-45,44,-37,44,-24,35,-29]);
    poly(g, 0x293f48, [-29,-50,-20,-61,34,-61,52,-49,42,-45,-29,-45]);
    poly(g, 0x6d8888, [-26,-52,-18,-59,32,-59,48,-51,36,-50]);
    box(g, 0x223740, -14, -74, 9, 16);
    box(g, 0xc36c57, -13, -71, 7, 5);
    line(g, 0x242f37, 2, [22,-61,22,-89]);
    poly(g, 0xec8462, [23,-88,42,-85,29,-78,23,-79]);
    box(g, 0x242f37, 34, -11, 4, 10);
    dot(g, 0x2a3337, 36, -13, 8);
    dot(g, AMBER, 36, -13, 5.7);
    dot(g, 0x293e45, 36, -13, 3.5);
    line(g, AMBER, 1, [31,-13,41,-13]);
    dot(g, 0x78e2b8, 99, -9, 5, .19);
    dot(g, 0x9ef4bc, 99, -9, 2.4);
    dot(g, 0xf99776, -104, -11, 2.2);
  });
  label(game, '雨 燕', 5, 23, 10, PAPER, 'center', true, boat);
  run.boat = boat;
}

function crew(game) {
  run.crate = sprite(game, jobs[0].x, jobs[0].y, g => {
    oval(g, INK, -19, -3, 40, 9, .4);
    poly(g, 0x4b3026, [-19,-23,-10,-29,21,-29,21,-5,12,1,-19,1]);
    poly(g, 0xd49554, [-18,-22,12,-22,12,-1,-18,-1]);
    poly(g, 0xeeb472, [-18,-23,-10,-28,21,-28,12,-23]);
    poly(g, 0x996040, [13,-22,20,-27,20,-6,13,-1]);
    box(g, 0xf2c68a, -15, -22, 3, 21);
    box(g, 0xf2c68a, 6, -22, 3, 21);
    line(g, 0x956044, 1, [-11,-17,5,-17]);
    line(g, 0x956044, 1, [-11,-7,5,-7]);
  });
  label(game, '01', -3, -18, 10, INK, 'center', true, run.crate);
  run.shadow = sprite(game, 0, 0, g => oval(g, INK, -17, -4, 34, 10, .39));
  run.worker = sprite(game, run.x, run.y, () => {});
  run.feet = [-6, 6].map(x => sprite(game, x, -3, g => {
    box(g, 0x1f303b, -3, -9, 6, 11);
    box(g, 0x293439, -4, -1, 9, 4);
    box(g, 0x697471, -4, 2, 9, 1);
  }, run.worker));
  run.coat = sprite(game, 0, 0, g => {
    poly(g, 0x242f31, [-11,-26,-14,-9,-9,-7,11,-7,14,-12,10,-27]);
    poly(g, 0xeaa445, [-10,-26,-12,-11,-7,-8,10,-9,12,-13,8,-27]);
    poly(g, 0xffd678, [-9,-25,-10,-12,-4,-12,-4,-26]);
    line(g, 0xffe6af, 2, [-11,-12,10,-12]);
    line(g, 0xa76435, 1, [2,-25,2,-11]);
    dot(g, 0xefac52, -1, -30, 10);
    dot(g, 0xffd078, 0, -32, 8);
    poly(g, 0x5b4940, [0,-36,7,-36,11,-30,9,-25,3,-25,0,-28]);
    poly(g, 0xf2be8b, [4,-33,8,-33,10,-30,8,-27,4,-27]);
    dot(g, INK, 8, -31, .9);
    line(g, 0xffdf91, 2, [-7,-33,-5,-37,1,-39,8,-36]);
  }, run.worker);
  game.toFront(run.crate);
  run.marker = sprite(game, 0, 0, g => {
    line(g, AMBER, 1.6, [-22,-1,-29,3,-22,8]);
    line(g, AMBER, 1.6, [22,-1,29,3,22,8]);
    poly(g, AMBER, [-5,-51,5,-51,0,-45]);
  });
  run.waypoint = sprite(game, 0, 0, g => {
    line(g, PAPER, 1, [-8,0,0,-4,8,0,0,4,-8,0], .75);
    dot(g, PAPER, 0, 0, 1.1);
  });
  run.waypoint.visible = false;
}

function channel(game) {
  run.gateArt = gates.map((gate, i) => {
    const p = sprite(game, gate.x, gate.y, g => {
      for (let y = -47; y < 50; y += 13) line(g, MINT, 1.2, [0,y,0,y+6], .55);
      for (const y of [-61, 61]) {
        oval(g, 0x183c46, -14, y-2, 28, 8, .6);
        oval(g, MINT, -12, y, 24, 6, .26);
        poly(g, 0x254653, [-8,y,-5,y-9,5,y-9,8,y,4,y+3,-4,y+3]);
        poly(g, y < 0 ? 0xd98462 : 0x7dc4b1, [-7,y,-4,y-9,4,y-9,7,y,0,y+2]);
        box(g, 0xf5e2a9, -5, y-6, 10, 2);
        box(g, 0x273e49, -1, y-16, 2, 8);
        dot(g, AMBER, 0, y-16, 5, .24);
        dot(g, PAPER, 0, y-16, 2.4);
      }
    });
    label(game, String(i+1), 14, -15, 16, PAPER, 'left', true, p);
    p.visible = false;
    return p;
  });
}

function weather(game) {
  run.rain = Array.from({ length: 78 }, (_, i) => {
    const len = game.random.range(5, 18);
    const s = sprite(game, 0, 0, g => line(g, i % 6 ? 0xaac7cd : 0xe0e5d9, i % 6 ? .8 : 1.2, [0,0,-len*.44,len]), game.ui);
    return { s, x: game.random.range(0, W+32), y: game.random.range(0, H+22), speed: game.random.range(190, 550) };
  });
  run.flash = game.rect(W/2, H/2, W, H, 0xdeeef7, game.ui);
  run.flash.alpha = 0;
}

function hud(game) {
  sprite(game, 0, 0, g => {
    box(g, 0x172632, 0, 0, 960, 106, .83);
    box(g, 0x203944, 0, 105, 960, 1);
    box(g, AMBER, 26, 24, 3, 52);
    box(g, 0x324852, 302, 26, 1, 53);
    box(g, 0x324852, 711, 26, 1, 53);
    box(g, 0x121f2c, 0, 465, 960, 75, .94);
    box(g, 0x465a62, 0, 465, 960, 1);
    box(g, 0x405560, 741, 76, 185, 5);
  }, game.ui);
  label(game, '暴雨渡口', 42, 18, 38, PAPER, 'left', true);
  label(game, '雨燕号　/　末班摆渡', 43, 67, 14, 0xaec0c1);
  label(game, '暴雨抵达前', 741, 25, 14, 0xd3dfd9);
  run.clock = label(game, '00:50', 927, 20, 32, AMBER, 'right', true);
  run.gauge = sprite(game, 741, 76, g => box(g, AMBER, 0, 0, 185, 5), game.ui);
  run.steps = ['取货', '装船', '离港'].map((word, i) => {
    const x = 370 + 138*i;
    if (i < 2) sprite(game, x, 44, g => box(g, 0x41606a, 23, 0, 92, 1), game.ui);
    const badge = game.circle(x, 44, 15, 0x344b55, game.ui);
    const core = game.circle(x, 44, 11, INK, game.ui);
    const num = label(game, String(i+1), x, 34, 15, PAPER, 'center', true);
    const name = label(game, word, x, 66, 15, 0xbecbc8, 'center');
    return { badge, core, num, name };
  });
  run.tip = label(game, '', 28, 477, 20, PAPER, 'left', true);
  run.help = label(game, '', 29, 509, 13, 0xb6c7cb);
  run.action = game.button('抱起货箱', { x: 824, y: 502, width: 216, height: 46, color: AMBER, textColor: INK, size: 20 }, () => {
    if (run.end) return;
    if (run.phase < 3) setRoute(game, jobs[run.phase], true);
    else {
      run.steerY = gates[Math.min(run.gate, gates.length-1)].y;
      game.sfx.play('click', { volume: .35 });
    }
  });
  refreshHud();
}

function refreshHud() {
  const stage = Math.min(2, run.phase);
  run.steps.forEach((s, i) => {
    s.badge.alpha = i === stage ? 1 : .65;
    s.core.alpha = i === stage ? .18 : 1;
    s.num.text = i < stage ? '✓' : String(i+1);
    s.num.color = i < stage ? MINT : i === stage ? AMBER : 0xb4c6c7;
    s.name.color = i === stage ? AMBER : i < stage ? MINT : 0xb4c6c7;
  });
  if (run.phase < 3) {
    const job = jobs[run.phase];
    run.tip.text = job.tip;
    run.help.text = '方向键 / WASD 移动　·　E / 空格互动　·　也可点击目标';
    run.action.label.text = job.verb;
  } else {
    run.tip.text = run.gate < 3 ? '驶过浮标 ' + (run.gate + 1) + ' / 3' : '航道已清空，继续驶离渡口。';
    run.help.text = '↑ ↓ / W S 转向　·　点击水面设定航向';
    run.action.label.text = '对准下一道浮标';
  }
}

function onDeck(x, y) {
  return x >= 532 && x <= 702 && y >= 344 && y <= 383;
}
function walkable(x, y) {
  return (x >= 19 && x <= 489 && y >= (x < 225 ? 351 : 320) && y <= 408) ||
    (x >= 486 && x <= 541 && y >= 358 && y <= 378) || onDeck(x, y);
}
function setRoute(game, target, use) {
  run.started = true;
  const points = [];
  if (run.x < 489 && target.x >= 489) points.push({ x: 473, y: 369 });
  if (run.x > 540 && target.x <= 540) points.push({ x: 550, y: 369 });
  if (run.x <= 540 && target.x > 540) points.push({ x: 550, y: 369 });
  if (run.x >= 489 && target.x < 489) points.push({ x: 473, y: 369 });
  points.push(target);
  run.route = points;
  run.autoUse = use;
  run.waypoint.x = target.x;
  run.waypoint.y = target.y;
  run.waypoint.visible = !use;
  game.sfx.play('click', { volume: .22 });
}

function interact(game) {
  const job = jobs[run.phase];
  if (!job || dist(run, job) > 30) return;
  run.route = [];
  run.waypoint.visible = false;
  run.phase++;
  run.marker.visible = run.phase < 3;
  run.stepTime = .24;
  if (run.phase === 1) {
    game.sfx.play('pop', { pitch: .8 });
    game.burst(job.x, job.y-9, { color: AMBER, count: 6, life: .32, speed: 38, size: 2 });
  } else if (run.phase === 2) {
    game.sfx.play('hit', { volume: .43, pitch: .85 });
    game.sfx.play('coin', { volume: .37 });
    game.burst(job.x, job.y, { color: MINT, count: 12, life: .48, speed: 61, size: 2 });
  } else {
    run.x = job.x;
    run.y = job.y;
    run.rope.visible = false;
    game.tween(run.ramp).to({ rotation: -21, alpha: 0 }, .55, 'quadIn');
    run.gateArt.forEach((p, i) => { p.visible = true; p.alpha = i ? .32 : 1; });
    game.sfx.play('ferry', { volume: .55 });
    game.burst(543, 338, { color: AMBER, count: 8, life: .42, speed: 47, size: 2 });
  }
  refreshHud();
}

function walking(game, dt) {
  const p = game.pointer;
  const job = jobs[run.phase];
  if (p.pressed && p.y > 108 && p.y < 465) {
    const target = { x: p.x + game.view.x, y: p.y };
    if (Math.abs(target.x-job.x) < 42 && target.y > job.y-61 && target.y < job.y+24) setRoute(game, job, true);
    else if (walkable(target.x, target.y)) setRoute(game, target, false);
  }
  let { x, y } = game.keys.axis();
  if (Math.hypot(x, y) > .14) {
    run.started = true;
    run.route = [];
    run.waypoint.visible = false;
  } else if (run.route.length) {
    x = run.route[0].x - run.x;
    y = run.route[0].y - run.y;
    if (Math.hypot(x, y) < 5) {
      run.route.shift();
      x = 0;
      y = 0;
      if (!run.route.length) {
        run.waypoint.visible = false;
        if (run.autoUse) interact(game);
      }
    }
  }
  const input = Math.hypot(x, y);
  const speed = run.phase === 1 ? 146 : 184;
  const dx = x / Math.max(1, input) * speed * dt;
  const dy = y / Math.max(1, input) * speed * dt;
  const startX = run.x, startY = run.y;
  if (walkable(run.x+dx, run.y)) run.x += dx;
  if (walkable(run.x, run.y+dy)) run.y += dy;
  run.moving = Math.hypot(run.x-startX, run.y-startY) > .05;
  if (Math.abs(dx) > .2) run.facing = Math.sign(dx);
  if (game.keys.pressed('e', 'space', 'enter', 'pad:a')) {
    run.started = true;
    if (dist(run, jobs[Math.min(2,run.phase)]) <= 30 && job === jobs[run.phase]) interact(game);
    else if (run.phase < 3 && job === jobs[run.phase]) {
      run.tip.text = '再靠近些 · ' + job.verb;
      run.nudge = 1.25;
    }
  }
}

function sail(game, dt) {
  const p = game.pointer;
  if (p.pressed && p.y >= 243 && p.y < 465) run.steerY = clamp(p.y, 285, 441);
  const stick = game.keys.axis().y;
  if (Math.abs(stick) > .12) run.steerY = null;
  const dy = run.steerY === null ? stick * 123 : clamp((run.steerY-run.by)*5, -123, 123);
  run.vy = lerp(run.vy, dy, Math.min(1, dt*5));
  run.by = clamp(run.by + run.vy*dt, 285, 441);
  const gate = gates[run.gate];
  const nearGate = gate && run.bx >= gate.x-5;
  const aligned = gate && Math.abs(run.by-gate.y) <= 27;
  const waiting = nearGate && !aligned;
  run.speed = lerp(run.speed, waiting ? 0 : 119, Math.min(1, dt*3.8));
  const next = run.bx + run.speed*dt;
  run.bx = gate ? Math.min(next, gate.x) : next;
  run.boat.rotation = lerp(run.boat.rotation, run.vy*.065, Math.min(1,dt*5));
  if (nearGate && aligned) {
    game.sfx.play('coin', { volume: .55, pitch: 1 + run.gate*.16 });
    game.burst(gate.x, gate.y+26, { color: MINT, count: 13, life: .65, speed: 60, size: 2 });
    run.gateArt[run.gate].alpha = .2;
    run.gate++;
    if (run.gate < gates.length) run.gateArt[run.gate].alpha = 1;
    else run.action.label.text = '航道已通过';
    refreshHud();
    if (run.gate === gates.length) run.action.label.text = '航道已通过';
  } else if (gate) {
    run.tip.text = waiting ? (run.by < gate.y ? '向下转向，驶入浮标之间。' : '向上转向，驶入浮标之间。') : '驶过浮标 ' + (run.gate+1) + ' / 3';
  }
  const desiredView = clamp(run.bx-580, 0, 754);
  game.view.x = lerp(game.view.x, desiredView, Math.min(1, dt*3));
  if (run.bx > 1450) finish(game, true);
}

function animate(game, dt) {
  const t = run.t;
  const storm = 1-run.left/LIMIT;
  const bob = Math.sin(t*2.25)*1.65 + Math.sin(t*3.8)*.48;
  run.boat.x = run.bx;
  run.boat.y = run.by + bob;
  if (run.phase < 3) run.boat.rotation = Math.sin(t*1.8)*.68;
  const angle = run.boat.rotation*Math.PI/180;
  const cos = Math.cos(angle), sin = Math.sin(angle);
  function place(s, x, y) {
    s.x = run.boat.x + x*cos-y*sin;
    s.y = run.boat.y + x*sin+y*cos;
  }
  if (run.phase >= 3) place(run.worker, 36, -9);
  else if (onDeck(run.x, run.y)) place(run.worker, run.x-MOOR.x, run.y-MOOR.y);
  else { run.worker.x = run.x; run.worker.y = run.y; }
  run.shadow.x = run.worker.x;
  run.shadow.y = run.worker.y;
  run.worker.scaleX = run.facing;
  const stride = run.moving && run.phase < 3 ? Math.sin(t*20)*4 : 0;
  run.feet.forEach((s, i) => { s.y = -3 + stride*(i ? -1 : 1); });
  run.coat.y = -Math.abs(stride)*.4 + Math.sin(run.stepTime*13)*2;
  if (run.phase === 1) {
    run.crate.x = run.worker.x + run.facing*8;
    run.crate.y = run.worker.y - 15 + run.coat.y;
    run.crate.scaleX = .8;
    run.crate.scaleY = .8;
  } else if (run.phase >= 2) {
    place(run.crate, -56, 9);
    run.crate.rotation = run.boat.rotation;
    run.crate.scaleX = .86;
    run.crate.scaleY = .86;
  }
  if (run.phase < 3) {
    const job = jobs[run.phase];
    run.marker.x = job.x;
    run.marker.y = job.y + (run.phase ? bob : 0) + Math.sin(t*4)*2;
    run.marker.alpha = .8 + .2*Math.sin(t*5);
  }
  run.ripples.forEach(({s,x,y,phase}) => {
    s.x = x + Math.sin(t*.8+phase)*14;
    s.y = y + Math.cos(t+phase)*1.8;
    s.alpha = .12 + .23*(.5+.5*Math.sin(t*1.7+phase));
  });
  run.wake.forEach((s, i) => {
    s.visible = run.phase >= 3 && run.speed > 7;
    if (!s.visible) return;
    const f = (t*1.32+(i>>1)/7)%1;
    s.x = run.bx - 99 - f*154;
    s.y = run.by + (i%2 ? 1 : -1)*(9+f*31) + 4*Math.sin(t*5+i);
    s.scaleX = .45 + f*1.7;
    s.alpha = (1-f)*(.2+run.speed/195);
  });
  run.rain.forEach((r, i) => {
    r.x -= r.speed*.34*dt;
    r.y += r.speed*dt;
    if (r.y > H+8) { r.y -= H+34; r.x += 171; }
    if (r.x < -14) r.x += W+28;
    if (r.x > W+14) r.x -= W+28;
    r.s.x = r.x;
    r.s.y = r.y;
    r.s.alpha = (.17 + storm*.37) * (i%4 ? .67 : 1);
  });
  run.flash.alpha = Math.max(0, run.flash.alpha-dt*1.1);
}

function finish(game, won) {
  if (run.end) return;
  run.end = true;
  game.sfx.play(won ? 'win' : 'lose', { volume: .58 });
  sprite(game, 0, 0, g => {
    box(g, 0x101c27, 0, 0, W, H, .67);
    g.beginFill(0x1c303b).drawRoundRect(244, 145, 472, 251, 15).endFill();
    box(g, won ? MINT : AMBER, 449, 167, 62, 3);
  }, game.ui);
  label(game, won ? '渡船已离港' : '暴雨封航', 480, 188, 43, PAPER, 'center', true);
  const sub = won ? '第一箱货已装船 · 用时 ' + Math.ceil(LIMIT-run.left) + ' 秒' : run.phase < 2 ? '第一箱货还没装好，渡船留在港内。' : '第一箱货已经装好，渡船未能及时离港。';
  label(game, sub, 480, 251, 18, 0xd0ded9, 'center');
  game.button('再跑一趟', { x: 480, y: 322, width: 204, height: 49, color: won ? MINT : AMBER, textColor: INK, size: 20 }, () => game.restart());
  label(game, 'Enter / R 重开', 480, 360, 13, 0xa9b9bc, 'center');
}

await Egret.play({
  width: W, height: H, background: 0x152631, seed: 137,
  setup(game) {
    run = {
      t: 0, left: LIMIT, started: false, end: false, phase: 0, gate: 0,
      x: 238, y: 376, bx: MOOR.x, by: MOOR.y, vy: 0, speed: 0,
      facing: 1, moving: false, route: [], autoUse: false, steerY: null,
      nudge: 0, stepTime: 0, lastSecond: LIMIT, thunder: false
    };
    game.sfx.define('ferry', [
      { wave: 'triangle', from: 130, to: 113, seconds: .72, decay: .7, volume: .45 },
      { wave: 'sine', from: 180, to: 147, seconds: .28, volume: .24 }
    ]);
    scenery(game);
    dock(game);
    channel(game);
    ferry(game);
    crew(game);
    weather(game);
    hud(game);
    animate(game, 0);
  },
  update(dt, game) {
    dt = Math.min(dt, .05);
    run.t += dt;
    if (run.end) {
      if (game.keys.pressed('enter', 'r')) game.restart();
      else animate(game, dt);
      return;
    }
    if (run.phase < 3) walking(game, dt);
    else sail(game, dt);
    run.stepTime = Math.max(0, run.stepTime-dt);
    if (run.nudge > 0) {
      run.nudge -= dt;
      if (run.nudge <= 0) refreshHud();
    }
    if (run.started && !run.end) {
      run.left = Math.max(0, run.left-dt);
      const seconds = Math.ceil(run.left);
      run.gauge.scaleX = Math.max(.001, run.left/LIMIT);
      if (run.lastSecond !== seconds) {
        run.clock.text = '00:' + String(seconds).padStart(2, '0');
        run.lastSecond = seconds;
        if (seconds <= 10) run.clock.color = 0xffa08c;
        if (seconds <= 5 && seconds > 0) game.sfx.play('click', { volume: .26, pitch: .73 });
      }
      if (!run.thunder && seconds <= 14) {
        run.thunder = true;
        run.flash.alpha = game.reducedMotion ? .06 : .25;
        game.sfx.play('wind', { volume: .32, pitch: .7 });
      }
      if (run.left <= 0) finish(game, false);
    }
    animate(game, dt);
  }
});
